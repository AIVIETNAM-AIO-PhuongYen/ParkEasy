import React from 'react';
import { useParkEasy } from '../context/ParkEasyContext';
import { AppViewMode } from '../types/parkeasy';
import { 
  Smartphone, 
  Layers, 
  MapPin, 
  FileText, 
  RefreshCw, 
  Activity,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    viewMode, 
    setViewMode, 
    isLiveSimulating, 
    toggleLiveSimulation, 
    triggerManualLotSync,
    isStaffOffline,
    pendingSyncCount
  } = useParkEasy();

  const navItems: { mode: AppViewMode; label: string; icon: React.ReactNode }[] = [
    { mode: 'b2c', label: 'Người gửi xe (B2C)', icon: <Smartphone className="w-4 h-4" /> },
    { mode: 'b2b', label: 'Nhân viên bãi (B2B)', icon: <ShieldCheck className="w-4 h-4" /> },
    { mode: 'map', label: 'Bản đồ Metro & Bãi xe', icon: <MapPin className="w-4 h-4" /> },
    { mode: 'project-info', label: 'Đề án & Kế hoạch (QTKN)', icon: <FileText className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#123B46] text-white border-b border-[#1A4D5B] shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-16">
          
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#20B7A6] to-[#D4F069] flex items-center justify-center shadow-sm">
              {/* ParkEasy Monogram: P + E + Map Pin */}
              <div className="font-bold text-[#123B46] text-lg leading-none tracking-tighter flex items-center">
                <span>P</span>
                <span className="text-[10px] -ml-0.5 bg-[#123B46] text-[#D4F069] px-0.5 rounded">E</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-lg tracking-tight text-white flex items-center gap-1.5 whitespace-nowrap">
                ParkEasy
                <span className="text-[10px] uppercase font-semibold tracking-wider bg-[#20B7A6]/20 text-[#20B7A6] border border-[#20B7A6]/40 px-1.5 py-0.5 rounded-full">
                  Demo Live
                </span>
              </span>
              <span className="text-[10px] text-slate-300 hidden sm:inline whitespace-nowrap">
                Lựa chọn cho hành trình dễ dàng hơn
              </span>
            </div>
          </div>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-1 bg-[#0A262E] p-1 rounded-xl border border-[#1A4D5B] overflow-x-auto">
            {navItems.map((item) => {
              const active = viewMode === item.mode;
              return (
                <button
                  key={item.mode}
                  onClick={() => setViewMode(item.mode)}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-[#20B7A6] text-[#123B46] shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action / simulation controller */}
          <div className="flex items-center gap-2.5 shrink-0">
            {isStaffOffline ? (
              <div className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                <span>Ngoại tuyến ({pendingSyncCount})</span>
              </div>
            ) : (
              <button
                onClick={toggleLiveSimulation}
                title="Bật/Tắt cập nhật thời gian thực"
                className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors border ${
                  isLiveSimulating
                    ? 'bg-[#20B7A6]/15 text-[#20B7A6] border-[#20B7A6]/30 hover:bg-[#20B7A6]/25'
                    : 'bg-white/5 text-slate-400 border-white/10 hover:text-white'
                }`}
              >
                <Activity className={`w-3.5 h-3.5 ${isLiveSimulating ? 'text-[#20B7A6] animate-pulse' : ''}`} />
                <span className="whitespace-nowrap">
                  {isLiveSimulating ? 'Live Sync' : 'Đã dừng Sync'}
                </span>
              </button>
            )}

            <button
              onClick={triggerManualLotSync}
              title="Làm mới đồng bộ ngay"
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white transition-colors border border-white/10"
              aria-label="Làm mới dữ liệu"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden items-center justify-between gap-1 py-2 overflow-x-auto border-t border-[#1A4D5B]">
          {navItems.map((item) => {
            const active = viewMode === item.mode;
            return (
              <button
                key={item.mode}
                onClick={() => setViewMode(item.mode)}
                className={`flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md whitespace-nowrap shrink-0 ${
                  active ? 'bg-[#20B7A6] text-[#123B46]' : 'text-slate-300'
                }`}
              >
                {item.icon}
                <span>{item.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
