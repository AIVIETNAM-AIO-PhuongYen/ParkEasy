import React, { useState } from 'react';
import { useParkEasy } from '../context/ParkEasyContext';
import { METRO_STATIONS } from '../data/initialData';
import { ParkingLot } from '../types/parkeasy';
import { 
  MapPin, 
  Navigation, 
  Clock, 
  Shield, 
  ExternalLink, 
  Search, 
  Sparkles,
  Train,
  ChevronRight
} from 'lucide-react';

export const MetroMapView: React.FC = () => {
  const { 
    parkingLots, 
    selectedLotId, 
    setSelectedLotId,
    activeLot,
    setViewMode,
    addToast 
  } = useParkEasy();

  const [activeStationName, setActiveStationName] = useState<string>('Ga Đại học Quốc gia');

  // Find lots near active station
  const lotsNearStation = parkingLots.filter((l) => l.station === activeStationName || l.area.includes(activeStationName.replace('Ga ', '')));

  const formatMoney = (n: number) => n.toLocaleString('vi-VN') + ' đ';

  const getStatusColor = (lot: ParkingLot) => {
    if (lot.free === 0) return { bg: 'bg-red-500', text: 'text-red-700', badge: 'bg-red-50 text-red-700 border-red-200' };
    if (lot.free / lot.cap <= 0.15) return { bg: 'bg-amber-500', text: 'text-amber-800', badge: 'bg-amber-50 text-amber-800 border-amber-200' };
    return { bg: 'bg-emerald-500', text: 'text-emerald-700', badge: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
  };

  return (
    <div className="py-6 px-4 sm:px-6 max-w-7xl mx-auto space-y-6">
      
      {/* Title & Introduction */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#123B46] text-[#D4F069] flex items-center justify-center font-bold">
              <Train className="w-4 h-4" />
            </div>
            <h2 className="font-extrabold text-base text-[#123B46]">
              Bản Đồ Mạng Lưới Tuyến Metro Số 1 & Bãi Đỗ Xe ParkEasy
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Tuyến Bến Thành – Suối Tiên (19.7 km, 14 nhà ga) kết nối giải pháp đỗ xe Park & Ride giúp người dân trung chuyển nhanh chóng.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            Còn chỗ
          </span>
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 font-semibold border border-amber-200">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            Sắp đầy (&lt;15%)
          </span>
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-50 text-red-700 font-semibold border border-red-200">
            <span className="w-2 h-2 rounded-full bg-red-500"></span>
            Hết chỗ (0)
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        
        {/* Left 2 Cols: Schematic Interactive Route Map */}
        <div className="lg:col-span-2 bg-[#123B46] rounded-3xl p-5 text-white shadow-md border border-[#1A4D5B] space-y-5">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#D4F069] tracking-wider">
                Sơ đồ tuyến Metro số 1
              </span>
              <h3 className="font-extrabold text-sm text-white mt-0.5">
                Nhấp vào ga để xem các bãi đỗ xe liên kết
              </h3>
            </div>
            <span className="text-xs bg-[#20B7A6] text-[#123B46] px-2.5 py-1 rounded-full font-bold">
              14 Nhà ga
            </span>
          </div>

          {/* Metro Route Vector Visualization */}
          <div className="relative py-4 overflow-x-auto">
            {/* The main rail line bar */}
            <div className="min-w-[680px] px-4 space-y-6">
              
              {/* Rail track line */}
              <div className="relative">
                <div className="h-2.5 bg-gradient-to-r from-[#20B7A6] via-[#D4F069] to-[#20B7A6] rounded-full shadow-inner"></div>
                
                {/* Stations nodes */}
                <div className="flex justify-between items-center -mt-4">
                  {METRO_STATIONS.map((st, i) => {
                    const isSelected = activeStationName === st.name;
                    const lotsAtStation = parkingLots.filter((l) => l.station === st.name);
                    const hasLot = lotsAtStation.length > 0;

                    return (
                      <div
                        key={st.id}
                        onClick={() => setActiveStationName(st.name)}
                        className="flex flex-col items-center cursor-pointer group"
                        style={{ width: `${100 / METRO_STATIONS.length}%` }}
                      >
                        <div
                          className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                            isSelected
                              ? 'bg-[#D4F069] border-white scale-125 shadow-lg'
                              : hasLot
                              ? 'bg-[#20B7A6] border-white group-hover:scale-110'
                              : 'bg-[#123B46] border-slate-400'
                          }`}
                        >
                          <span className={`text-[10px] font-bold ${isSelected ? 'text-[#123B46]' : 'text-white'}`}>
                            {i + 1}
                          </span>
                        </div>

                        <span
                          className={`text-[9px] mt-2 text-center whitespace-nowrap transition-colors max-w-[50px] truncate ${
                            isSelected ? 'font-bold text-[#D4F069]' : 'text-slate-300 group-hover:text-white'
                          }`}
                        >
                          {st.name.replace('Ga ', '')}
                        </span>

                        {hasLot && (
                          <div className="mt-1 flex items-center gap-0.5">
                            {lotsAtStation.map((l) => (
                              <span
                                key={l.id}
                                className={`w-2 h-2 rounded-full ${getStatusColor(l).bg}`}
                                title={`${l.name}: Còn ${l.free} chỗ`}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Station details preview */}
              <div className="bg-[#0A262E] p-4 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-white">{activeStationName}</span>
                    <span className="text-[10px] bg-white/10 text-slate-300 px-2 py-0.5 rounded">
                      {METRO_STATIONS.find((s) => s.name === activeStationName)?.district}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    Có {lotsNearStation.length} bãi xe máy ParkEasy đang hoạt động quanh khu vực này.
                  </p>
                </div>

                <button
                  onClick={() => {
                    if (lotsNearStation.length > 0) {
                      setSelectedLotId(lotsNearStation[0].id);
                      setViewMode('dual');
                    }
                  }}
                  className="px-3.5 py-1.5 bg-[#20B7A6] hover:bg-[#1AA393] text-[#123B46] font-bold rounded-lg shrink-0 transition-colors"
                >
                  Mở trên điện thoại demo
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Geographic Card Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            {parkingLots.map((lot) => {
              const colors = getStatusColor(lot);
              const isSelected = selectedLotId === lot.id;

              return (
                <div
                  key={lot.id}
                  onClick={() => {
                    setSelectedLotId(lot.id);
                    setActiveStationName(lot.station);
                  }}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white/15 border-[#D4F069] shadow-md ring-1 ring-[#D4F069]'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${colors.bg} shrink-0`}></span>
                        <h4 className="font-bold text-xs text-white truncate">{lot.name}</h4>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-1 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span>Cách ga {lot.dist}m</span>
                        <span>·</span>
                        <span className="text-[#D4F069] font-semibold">{formatMoney(lot.priceDay)}</span>
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-sm font-black text-white">{lot.free}</span>
                      <span className="text-[10px] text-slate-300 block">/ {lot.cap} chỗ</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Selected Lot Card & GPS Navigator */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] uppercase font-bold text-[#20B7A6] tracking-wider">
                Bãi xe đang chọn
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusColor(activeLot).badge}`}>
                {activeLot.free === 0 ? 'Hết chỗ' : activeLot.free / activeLot.cap <= 0.15 ? 'Sắp đầy' : 'Còn chỗ'}
              </span>
            </div>
            <h3 className="font-extrabold text-sm text-[#123B46]">{activeLot.name}</h3>
            <p className="text-xs text-slate-500 mt-1 flex items-start gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
              <span>{activeLot.address}</span>
            </p>
          </div>

          {/* Metric cards */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <span className="text-[10px] text-slate-500 block">Số chỗ trống:</span>
              <span className="text-lg font-black text-[#123B46]">{activeLot.free} chỗ</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <span className="text-[10px] text-slate-500 block">Khoảng cách đi bộ:</span>
              <span className="text-lg font-black text-[#123B46]">{activeLot.dist}m</span>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5 text-xs">
            <div className="flex items-center justify-between text-slate-600">
              <span>Giá gửi ban ngày:</span>
              <strong className="text-[#123B46]">{formatMoney(activeLot.priceDay)}/lượt</strong>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span>Giá gửi ban đêm:</span>
              <strong className="text-[#123B46]">{formatMoney(activeLot.priceNight)}/lượt</strong>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span>Giờ mở cửa:</span>
              <strong className="text-[#123B46]">{activeLot.hours}</strong>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span>Nhận qua đêm:</span>
              <strong className="text-[#123B46]">{activeLot.night}</strong>
            </div>
          </div>

          {/* Action buttons */}
          <div className="space-y-2 pt-1">
            <button
              onClick={() => {
                addToast(
                  'Chỉ đường Google Maps',
                  `Đang khởi chạy định vị cổng vào ${activeLot.name} (Tọa độ: ${activeLot.coordinates.lat}, ${activeLot.coordinates.lng})`,
                  'info'
                );
              }}
              className="w-full py-2.5 px-3 bg-[#123B46] hover:bg-[#1A4D5B] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-xs"
            >
              <Navigation className="w-4 h-4 text-[#D4F069]" />
              <span>Chỉ đường tới cổng bãi (Google Maps)</span>
              <ExternalLink className="w-3 h-3 text-slate-300" />
            </button>

            <button
              onClick={() => setViewMode('dual')}
              className="w-full py-2.5 px-3 bg-[#20B7A6] hover:bg-[#1AA393] text-[#123B46] text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <span>Xem trực tiếp trên Demo Phone B2C</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
