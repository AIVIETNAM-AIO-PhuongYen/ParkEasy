import React from 'react';
import { useParkEasy } from '../context/ParkEasyContext';
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useParkEasy();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isWarning = toast.type === 'warning';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-2xl shadow-lg border backdrop-blur-md flex items-start gap-3 transition-all animate-in fade-in slide-in-from-bottom-2 duration-300 ${
              isSuccess
                ? 'bg-[#123B46] text-white border-[#20B7A6]/50'
                : isWarning
                ? 'bg-amber-950 text-amber-100 border-amber-600/50'
                : isError
                ? 'bg-red-950 text-red-100 border-red-600/50'
                : 'bg-[#123B46]/95 text-white border-white/10'
            }`}
          >
            <div className="mt-0.5 shrink-0">
              {isSuccess && <CheckCircle2 className="w-4 h-4 text-[#20B7A6]" />}
              {isWarning && <AlertTriangle className="w-4 h-4 text-amber-400" />}
              {isError && <XCircle className="w-4 h-4 text-red-400" />}
              {toast.type === 'info' && <Info className="w-4 h-4 text-[#D4F069]" />}
            </div>

            <div className="flex-1 min-w-0">
              <h5 className="font-bold text-xs leading-tight">{toast.title}</h5>
              <p className="text-[11px] opacity-80 mt-0.5 leading-snug">{toast.message}</p>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="p-1 rounded-full opacity-60 hover:opacity-100 transition-opacity"
              aria-label="Đóng"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
