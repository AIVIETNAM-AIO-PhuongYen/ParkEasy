import React, { useState } from 'react';
import { useParkEasy } from '../context/ParkEasyContext';
import { VehicleType, ParkedVehicle } from '../types/parkeasy';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Wifi,
  WifiOff,
  RefreshCw,
  Camera,
  QrCode,
  Search,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  TrendingUp,
  DollarSign,
  Car,
  ChevronDown,
  ArrowLeft,
  Bike,
  Zap,
  Clock,
  ShieldAlert,
  SlidersHorizontal,
  X
} from 'lucide-react';

export const B2BApp: React.FC<{ isEmbedded?: boolean }> = ({ isEmbedded = false }) => {
  const {
    parkingLots,
    staffActiveLotId,
    setStaffActiveLotId,
    staffLot,
    isStaffOffline,
    toggleStaffOffline,
    pendingSyncCount,
    syncOfflineQueue,
    parkedVehicles,
    recentLogs,
    todayCashRevenue,
    todayDigitalRevenue,
    shiftClockMinute,
    recordVehicleIn,
    recordVehicleOut,
    performAuditCount,
    addToast,
    setViewMode
  } = useParkEasy();

  // Screen inside B2B staff
  const [b2bScreen, setB2bScreen] = useState<'home' | 'plate-in' | 'plate-out' | 'ticket-created' | 'out-confirm' | 'parked-list' | 'audit' | 'revenue'>('home');
  const [selectedType, setSelectedType] = useState<VehicleType>('Tay ga');
  const [inputDigits, setInputDigits] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [cameraActive, setCameraActive] = useState<boolean>(false);

  // Flow State
  const [lastTicket, setLastTicket] = useState<ParkedVehicle | null>(null);
  const [foundOutVehicle, setFoundOutVehicle] = useState<ParkedVehicle | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'Tiền mặt' | 'VietQR'>('Tiền mặt');
  const [searchParkedQuery, setSearchParkedQuery] = useState<string>('');

  // Audit state
  const [auditPhysicalCount, setAuditPhysicalCount] = useState<string>('52');
  const [auditResult, setAuditResult] = useState<{ discrepancy: number; discrepancyPercent: number; isWarning: boolean } | null>(null);

  // Keypad press handler
  const handleDigitPress = (digit: string) => {
    if (inputDigits.length < 4) {
      setInputDigits((prev) => prev + digit);
      setErrorMessage('');
    }
  };

  const handleDeleteDigit = () => {
    setInputDigits((prev) => prev.slice(0, -1));
    setErrorMessage('');
  };

  const handleClearDigits = () => {
    setInputDigits('');
    setErrorMessage('');
  };

  // Confirm In
  const handleConfirmIn = () => {
    const res = recordVehicleIn(inputDigits, selectedType, cameraActive);
    if (!res.success) {
      setErrorMessage(res.error || 'Có lỗi xảy ra');
      return;
    }
    setLastTicket(res.ticket || null);
    setInputDigits('');
    setCameraActive(false);
    setB2bScreen('ticket-created');
  };

  // Find vehicle for Out
  const handleFindVehicleForOut = (plateToFind?: string) => {
    const targetPlate = plateToFind || inputDigits;
    if (targetPlate.length !== 4) {
      setErrorMessage('Vui lòng nhập đủ 4 số cuối');
      return;
    }
    const found = parkedVehicles.find((v) => v.plate === targetPlate);
    if (!found) {
      setErrorMessage(`Không tìm thấy xe có 4 số cuối ${targetPlate} trong bãi!`);
      return;
    }
    setFoundOutVehicle(found);
    setB2bScreen('out-confirm');
  };

  // Confirm Out
  const handleConfirmOut = () => {
    if (!foundOutVehicle) return;
    const res = recordVehicleOut(foundOutVehicle.plate, paymentMethod);
    if (res.success) {
      setFoundOutVehicle(null);
      setInputDigits('');
      setB2bScreen('home');
    } else {
      setErrorMessage(res.error || 'Lỗi khi ghi xe ra');
    }
  };

  // Filter parked vehicles
  const filteredParked = parkedVehicles.filter((v) =>
    searchParkedQuery.trim() ? v.plate.includes(searchParkedQuery.trim()) : true
  );

  // 21x21 QR Matrix generator
  const generateQrMatrix = (seedStr: string) => {
    const N = 21;
    const matrix: boolean[][] = [];
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      hash = (hash << 5) - hash + seedStr.charCodeAt(i);
      hash |= 0;
    }
    const seed = Math.abs(hash) % 100;

    for (let r = 0; r < N; r++) {
      const row: boolean[] = [];
      for (let c = 0; c < N; c++) {
        const inTopLeft = r <= 6 && c <= 6;
        const inTopRight = r <= 6 && c >= 14;
        const inBottomLeft = r >= 14 && c <= 6;

        if (inTopLeft || inTopRight || inBottomLeft) {
          const rr = inBottomLeft ? r - 14 : r;
          const cc = inTopRight ? c - 14 : c;
          const isBorder = rr === 0 || rr === 6 || cc === 0 || cc === 6;
          const isCenter = rr >= 2 && rr <= 4 && cc >= 2 && cc <= 4;
          row.push(isBorder || isCenter);
        } else {
          const val = (r * 7 + c * 13 + r * c * 3 + seed) % 10;
          row.push(val < 4);
        }
      }
      matrix.push(row);
    }
    return matrix;
  };

  // Format helpers
  const formatMoney = (n: number) => n.toLocaleString('vi-VN') + ' đ';
  const getClockString = (min: number) => {
    const h = Math.floor(min / 60) % 24;
    const m = min % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  };

  const occupancyRatio = (staffLot.cap - staffLot.free) / staffLot.cap;
  const statusColor = staffLot.free === 0 ? 'text-red-600 bg-red-100 border-red-200' : occupancyRatio >= 0.85 ? 'text-amber-700 bg-amber-100 border-amber-200' : 'text-emerald-700 bg-emerald-100 border-emerald-200';
  const statusLabel = staffLot.free === 0 ? 'Hết chỗ' : occupancyRatio >= 0.85 ? 'Sắp đầy' : 'Còn chỗ';

  return (
    <div className={`flex flex-col bg-[#F3F6F5] text-[#123B46] select-none ${isEmbedded ? 'h-full min-h-0' : 'w-full h-[100dvh] min-h-0'}`}>
      
      {/* 1. Header: Lot Identity & Network Sync Status */}
      <div className="bg-[#123B46] text-white p-3.5 shrink-0 shadow-sm">
        <div className="flex items-center justify-between text-xs pb-1 border-b border-[#1A4D5B]">
          <div className="flex items-center gap-2">
            <span className="font-mono font-bold text-sm text-[#D4F069]">{getClockString(shiftClockMinute)}</span>
            <span className="text-[11px] text-slate-300">Ca sáng</span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
          {/* Offline switch */}
          <button
            onClick={toggleStaffOffline}
            className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold transition-all ${
              isStaffOffline
                ? 'bg-amber-400 text-amber-950 shadow-xs'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
            }`}
          >
            {isStaffOffline ? (
              <>
                <WifiOff className="w-3.5 h-3.5" />
                <span>Ngoại tuyến ({pendingSyncCount})</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5" />
                <span>Đã kết nối</span>
              </>
            )}
          </button>
          <button onClick={() => setViewMode('b2c')} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#D4F069] text-[#123B46] text-[11px] font-bold shadow-sm active:scale-95" aria-label="Chuyển sang giao diện người gửi xe">
            <ArrowLeft className="w-3.5 h-3.5" /><span>Người dùng</span>
          </button>
          </div>
        </div>

        {/* Lot selection & capacity pill */}
        <div className="flex items-center justify-between mt-2.5">
          <div className="min-w-0 pr-2">
            <div className="flex items-center gap-1 text-[11px] text-slate-300">
              <span>Bãi trực:</span>
              <select
                value={staffActiveLotId}
                onChange={(e) => setStaffActiveLotId(Number(e.target.value))}
                aria-label="Chọn bãi trực"
                className="bg-[#0A262E] text-white font-semibold rounded px-1.5 py-0.5 text-xs border border-white/10 focus:outline-none"
              >
                {parkingLots.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>
            <p className="font-extrabold text-sm text-white truncate mt-0.5">
              {staffLot.name}
            </p>
          </div>

          <div className={`px-2.5 py-1 rounded-xl text-xs font-bold border shrink-0 ${statusColor}`}>
            {statusLabel}
          </div>
        </div>

        {/* If offline with pending queue, show sync CTA button */}
        {isStaffOffline && pendingSyncCount > 0 && (
          <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-xs bg-amber-500/15 p-2 rounded-lg">
            <span className="text-[11px] text-amber-200">Đang lưu {pendingSyncCount} lượt xe trên máy</span>
            <button
              onClick={syncOfflineQueue}
              className="px-2 py-1 bg-amber-400 hover:bg-amber-300 text-amber-950 text-[11px] font-bold rounded-md flex items-center gap-1 transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Đồng bộ ngay</span>
            </button>
          </div>
        )}
      </div>

      {/* 2. Main Work Area */}
      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain pb-3">
        
        {/* ================= SCREEN: HOME ================= */}
        {b2bScreen === 'home' && (
          <div className="p-3.5 space-y-3.5">
            
            {/* Big Capacity & Occupancy Meter */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 block">Số chỗ còn trống:</span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-4xl font-black text-[#123B46]">{staffLot.free}</span>
                  <span className="text-xs text-slate-500 font-medium">/ {staffLot.cap} chỗ</span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs text-slate-500 block">Xe đang trong bãi:</span>
                <span className="text-xl font-extrabold text-[#123B46]">
                  {staffLot.cap - staffLot.free} <span className="text-xs font-normal text-slate-500">xe</span>
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  (Công suất {Math.round(occupancyRatio * 100)}%)
                </span>
              </div>
            </div>

            {/* TWO MASSIVE 1-TAP ACTION BUTTONS (< 3 chạm) */}
            <div className="grid grid-cols-2 gap-3">
              {/* BUTTON: XE VÀO */}
              <button
                onClick={() => {
                  setInputDigits('');
                  setErrorMessage('');
                  setB2bScreen('plate-in');
                }}
                className="py-5 px-3 bg-[#20B7A6] hover:bg-[#1AA393] active:scale-[0.98] text-[#123B46] rounded-2xl shadow-sm border border-[#1BA192] flex flex-col items-center justify-center gap-1.5 transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-white/30 flex items-center justify-center">
                  <ArrowDownLeft className="w-6 h-6 text-[#123B46]" />
                </div>
                <span className="text-base font-black tracking-tight uppercase">XE VÀO (+1)</span>
                <span className="text-[10px] font-semibold text-[#123B46]/80">Nhập 4 số cuối</span>
              </button>

              {/* BUTTON: XE RA */}
              <button
                onClick={() => {
                  setInputDigits('');
                  setErrorMessage('');
                  setB2bScreen('plate-out');
                }}
                className="py-5 px-3 bg-[#D4F069] hover:bg-[#C4E35A] active:scale-[0.98] text-[#123B46] rounded-2xl shadow-sm border border-[#BEDD50] flex flex-col items-center justify-center gap-1.5 transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-white/40 flex items-center justify-center">
                  <ArrowUpRight className="w-6 h-6 text-[#123B46]" />
                </div>
                <span className="text-base font-black tracking-tight uppercase">XE RA (-1)</span>
                <span className="text-[10px] font-semibold text-[#123B46]/80">Quét QR / Biển số</span>
              </button>
            </div>

            {/* Quick Actions Strip */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setB2bScreen('parked-list')}
                className="bg-white p-2.5 rounded-xl border border-slate-200 text-center hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <Car className="w-4 h-4 text-[#123B46] mx-auto mb-1" />
                <span className="text-xs font-bold text-[#123B46] block">{parkedVehicles.length}</span>
                <span className="text-[10px] text-slate-500">Xe trong bãi</span>
              </button>

              <button
                onClick={() => setB2bScreen('audit')}
                className="bg-white p-2.5 rounded-xl border border-slate-200 text-center hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <FileCheck className="w-4 h-4 text-[#20B7A6] mx-auto mb-1" />
                <span className="text-xs font-bold text-[#123B46] block">Đối soát</span>
                <span className="text-[10px] text-slate-500">Kiểm tra lệch</span>
              </button>

              <button
                onClick={() => setB2bScreen('revenue')}
                className="bg-white p-2.5 rounded-xl border border-slate-200 text-center hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <TrendingUp className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
                <span className="text-xs font-bold text-[#123B46] block">Doanh thu</span>
                <span className="text-[10px] text-slate-500">{formatMoney(todayCashRevenue + todayDigitalRevenue).split(' ')[0]}</span>
              </button>
            </div>

            {/* Recent Live Logs */}
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span>Nhật ký ra vào gần nhất</span>
                <span className="text-[10px] text-slate-400 font-normal">Tự động đồng bộ</span>
              </div>

              <div className="space-y-1.5">
                {recentLogs.slice(0, 4).map((log) => (
                  <div key={log.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 text-xs">
                    <div className="flex items-center gap-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${log.kind === 'Vào' ? 'bg-[#20B7A6] text-[#123B46]' : 'bg-[#D4F069] text-[#123B46]'}`}>
                        {log.kind}
                      </span>
                      <span className="font-mono font-bold text-slate-800">...{log.plate}</span>
                      <span className="text-[11px] text-slate-500">({log.type})</span>
                    </div>

                    <div className="flex items-center gap-2 text-right">
                      {log.fee && <span className="font-semibold text-emerald-700 text-[11px]">+{formatMoney(log.fee)}</span>}
                      <span className="text-[10px] text-slate-400">{log.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= SCREEN: PLATE IN ================= */}
        {b2bScreen === 'plate-in' && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2bScreen('home')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Hủy</span>
              </button>
              <h2 className="text-xs font-bold text-slate-700 uppercase">Ghi nhận xe vào</h2>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              {/* 1. Vehicle Type Selector */}
              <div>
                <span className="text-[11px] font-bold text-slate-500 block mb-1">Loại xe:</span>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['Xe số', 'Tay ga', 'Xe điện'] as VehicleType[]).map((t) => (
                    <button
                      key={t}
                      onClick={() => setSelectedType(t)}
                      className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                        selectedType === t
                          ? 'bg-[#123B46] text-white border-[#123B46]'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. 4-Digit Display */}
              <div className="text-center py-1">
                <span className="text-[11px] text-slate-500 block mb-1">Nhập 4 số cuối biển số:</span>
                <div className="flex items-center justify-center gap-2">
                  {[0, 1, 2, 3].map((idx) => {
                    const digit = inputDigits[idx] || '';
                    const isFocus = idx === inputDigits.length;
                    return (
                      <div
                        key={idx}
                        className={`w-12 h-14 rounded-xl border-2 flex items-center justify-center text-2xl font-mono font-black ${
                          digit
                            ? 'border-[#123B46] bg-slate-50 text-[#123B46]'
                            : isFocus
                            ? 'border-[#20B7A6] bg-emerald-50/50 text-[#20B7A6] animate-pulse'
                            : 'border-slate-200 bg-white text-slate-300'
                        }`}
                      >
                        {digit}
                      </div>
                    );
                  })}
                </div>
                {errorMessage && (
                  <p className="text-xs text-red-600 font-medium mt-1.5">{errorMessage}</p>
                )}
              </div>

              {/* Optional Camera Shot Simulation */}
              <div className="flex items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-slate-500" />
                  <span className="text-[11px] text-slate-700">Chụp ảnh xe đối chiếu</span>
                </div>
                <button
                  onClick={() => setCameraActive(!cameraActive)}
                  className={`px-2 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                    cameraActive ? 'bg-[#20B7A6] text-[#123B46]' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {cameraActive ? 'Đã bật camera' : 'Bật camera'}
                </button>
              </div>

              {/* 3. Number Keypad */}
              <div className="grid grid-cols-3 gap-2">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
                  <button
                    key={n}
                    onClick={() => handleDigitPress(n)}
                    className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-900 font-mono font-bold text-lg rounded-xl transition-colors shadow-2xs"
                  >
                    {n}
                  </button>
                ))}
                <button
                  onClick={handleClearDigits}
                  className="py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-xl"
                >
                  Xóa hết
                </button>
                <button
                  onClick={() => handleDigitPress('0')}
                  className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-900 font-mono font-bold text-lg rounded-xl"
                >
                  0
                </button>
                <button
                  onClick={handleDeleteDigit}
                  className="py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-xl"
                >
                  ←
                </button>
              </div>

              {/* Submit Button */}
              <button
                disabled={inputDigits.length !== 4}
                onClick={handleConfirmIn}
                className={`w-full py-3 rounded-xl font-black text-xs uppercase tracking-wider transition-all shadow-xs ${
                  inputDigits.length === 4
                    ? 'bg-[#20B7A6] hover:bg-[#1AA393] text-[#123B46]'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                Xác nhận xe vào ({inputDigits.length}/4)
              </button>
            </div>
          </div>
        )}

        {/* ================= SCREEN: TICKET CREATED (QR GENERATED) ================= */}
        {b2bScreen === 'ticket-created' && lastTicket && (
          <div className="p-3.5 space-y-3.5 text-center">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>

              <div>
                <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
                  Đã ghi nhận xe vào
                </span>
                <span className="text-xl font-mono font-black text-[#123B46] block mt-0.5">
                  Biển số: ...{lastTicket.plate}
                </span>
                <p className="text-xs text-slate-500 mt-0.5">{lastTicket.type} · Vào lúc {lastTicket.inAt}</p>
              </div>

              {/* Generated QR Ticket on Attendant's phone */}
              <div className="inline-block p-3 bg-white border-2 border-[#123B46] rounded-2xl shadow-sm mx-auto">
                <div className="grid grid-cols-21 gap-[2px] w-[147px] h-[147px]">
                  {generateQrMatrix(lastTicket.ticketCode).map((row, r) =>
                    row.map((on, c) => (
                      <div
                        key={`${r}-${c}`}
                        className={`w-full h-full ${on ? 'bg-[#123B46]' : 'bg-white'}`}
                      />
                    ))
                  )}
                </div>
              </div>

              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs">
                <span className="font-mono font-bold text-sm text-[#123B46] block">{lastTicket.ticketCode}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">
                  Khách chụp hoặc quét mã này để đối chiếu khi lấy xe
                </span>
              </div>

              <button
                onClick={() => setB2bScreen('home')}
                className="w-full py-2.5 bg-[#123B46] hover:bg-[#1A4D5B] text-white text-xs font-bold rounded-xl transition-colors"
              >
                Hoàn tất & Về trang chủ
              </button>
            </div>
          </div>
        )}

        {/* ================= SCREEN: PLATE OUT ================= */}
        {b2bScreen === 'plate-out' && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2bScreen('home')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Hủy</span>
              </button>
              <h2 className="text-xs font-bold text-slate-700 uppercase">Tìm xe ra & Thu phí</h2>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              {/* Quick Scan Simulator */}
              <div className="bg-[#EAF7F5] p-2.5 rounded-xl border border-[#20B7A6]/40 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-[#123B46] block">Quét nhanh mã QR của khách:</span>
                  <span className="text-[10px] text-slate-600 block">Chọn xe đỗ đầu tiên để thử nhanh</span>
                </div>
                <button
                  onClick={() => {
                    if (parkedVehicles.length > 0) {
                      handleFindVehicleForOut(parkedVehicles[0].plate);
                    } else {
                      setErrorMessage('Hiện chưa có xe nào trong bãi');
                    }
                  }}
                  className="px-2.5 py-1.5 bg-[#123B46] text-white font-bold text-xs rounded-lg flex items-center gap-1 hover:bg-[#1A4D5B]"
                >
                  <QrCode className="w-3.5 h-3.5 text-[#D4F069]" />
                  <span>Quét QR</span>
                </button>
              </div>

              <div className="relative text-center my-1">
                <span className="text-[11px] text-slate-400 bg-white px-2 relative z-10">hoặc gõ 4 số cuối biển số</span>
                <div className="absolute inset-x-0 top-1/2 border-t border-slate-200"></div>
              </div>

              {/* 4-Digit Display */}
              <div className="text-center py-1">
                <div className="flex items-center justify-center gap-2">
                  {[0, 1, 2, 3].map((idx) => {
                    const digit = inputDigits[idx] || '';
                    const isFocus = idx === inputDigits.length;
                    return (
                      <div
                        key={idx}
                        className={`w-12 h-14 rounded-xl border-2 flex items-center justify-center text-2xl font-mono font-black ${
                          digit
                            ? 'border-[#123B46] bg-slate-50 text-[#123B46]'
                            : isFocus
                            ? 'border-[#D4F069] bg-lime-50 text-slate-900 animate-pulse'
                            : 'border-slate-200 bg-white text-slate-300'
                        }`}
                      >
                        {digit}
                      </div>
                    );
                  })}
                </div>
                {errorMessage && (
                  <p className="text-xs text-red-600 font-medium mt-1.5">{errorMessage}</p>
                )}
              </div>

              {/* Keypad */}
              <div className="grid grid-cols-3 gap-2">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
                  <button
                    key={n}
                    onClick={() => handleDigitPress(n)}
                    className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-900 font-mono font-bold text-lg rounded-xl"
                  >
                    {n}
                  </button>
                ))}
                <button
                  onClick={handleClearDigits}
                  className="py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-xl"
                >
                  Xóa
                </button>
                <button
                  onClick={() => handleDigitPress('0')}
                  className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-900 font-mono font-bold text-lg rounded-xl"
                >
                  0
                </button>
                <button
                  onClick={handleDeleteDigit}
                  className="py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-xl"
                >
                  ←
                </button>
              </div>

              <button
                disabled={inputDigits.length !== 4}
                onClick={() => handleFindVehicleForOut()}
                className={`w-full py-3 rounded-xl font-black text-xs uppercase tracking-wider transition-all shadow-xs ${
                  inputDigits.length === 4
                    ? 'bg-[#D4F069] hover:bg-[#C4E35A] text-[#123B46]'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                Tra cứu xe ra ({inputDigits.length}/4)
              </button>
            </div>
          </div>
        )}

        {/* ================= SCREEN: OUT CONFIRM & COLLECT PAYMENT ================= */}
        {b2bScreen === 'out-confirm' && foundOutVehicle && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2bScreen('plate-out')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Tìm xe khác</span>
              </button>
              <h2 className="text-xs font-bold text-slate-700 uppercase">Xác nhận xe ra</h2>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3.5">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Biển số:</span>
                  <span className="font-mono font-black text-base text-[#123B46]">...{foundOutVehicle.plate}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Loại xe:</span>
                  <span className="font-bold text-slate-800">{foundOutVehicle.type}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Giờ vào:</span>
                  <span>{foundOutVehicle.inAt}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Thời gian gửi:</span>
                  <span className="font-semibold text-slate-700">~45 phút</span>
                </div>
              </div>

              {/* Total Fee Box */}
              <div className="bg-[#EAF7F5] p-3 rounded-xl border border-[#20B7A6]/50 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-600 block">Số tiền cần thu:</span>
                  <span className="text-2xl font-black text-[#123B46]">{formatMoney(staffLot.priceDay)}</span>
                </div>
                <span className="text-[10px] text-emerald-700 bg-white px-2 py-1 rounded-md font-bold border border-emerald-200">
                  Chuẩn QĐ 35
                </span>
              </div>

              {/* Payment Method Selector */}
              <div>
                <span className="text-[11px] font-bold text-slate-600 block mb-1">Phương thức thanh toán:</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setPaymentMethod('Tiền mặt')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'Tiền mặt'
                        ? 'bg-[#123B46] text-white border-[#123B46]'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>Tiền mặt</span>
                  </button>

                  <button
                    onClick={() => setPaymentMethod('VietQR')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'VietQR'
                        ? 'bg-[#20B7A6] text-[#123B46] border-[#20B7A6]'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>Khách quét VietQR</span>
                  </button>
                </div>
              </div>

              {paymentMethod === 'VietQR' && (
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-center text-xs">
                  <span className="text-[11px] text-slate-500 block">Mã VietQR thu 6.000đ</span>
                  <div className="inline-block p-2 bg-white border border-slate-300 rounded-lg mt-1">
                    <div className="grid grid-cols-21 gap-[1.5px] w-[84px] h-[84px]">
                      {generateQrMatrix('VIETQR-FEE-6000').map((row, r) =>
                        row.map((on, c) => (
                          <div key={`${r}-${c}`} className={`w-full h-full ${on ? 'bg-[#123B46]' : 'bg-white'}`} />
                        ))
                      )}
                    </div>
                  </div>
                </div>
              )}

              <button
                onClick={handleConfirmOut}
                className="w-full py-3 bg-[#D4F069] hover:bg-[#C4E35A] text-[#123B46] text-xs font-black rounded-xl uppercase tracking-wider shadow-xs transition-colors"
              >
                Xác nhận đã thu & Cho xe ra (+1 chỗ)
              </button>
            </div>
          </div>
        )}

        {/* ================= SCREEN: PARKED VEHICLES LIST ================= */}
        {b2bScreen === 'parked-list' && (
          <div className="p-3.5 space-y-3">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2bScreen('home')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Trang chủ</span>
              </button>
              <h2 className="text-xs font-bold text-slate-700">Xe đang gửi ({parkedVehicles.length})</h2>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Tìm xe theo 4 số cuối biển số..."
                value={searchParkedQuery}
                onChange={(e) => setSearchParkedQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none"
              />
            </div>

            <div className="space-y-2">
              {filteredParked.map((v) => (
                <div key={v.id} className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center font-bold text-xs text-[#123B46]">
                      {v.type === 'Tay ga' ? <Bike className="w-4 h-4 text-[#20B7A6]" /> : v.type === 'Xe điện' ? <Zap className="w-4 h-4 text-emerald-600" /> : <Bike className="w-4 h-4 text-slate-600" />}
                    </div>
                    <div>
                      <span className="font-mono font-extrabold text-sm text-[#123B46]">...{v.plate}</span>
                      <p className="text-[11px] text-slate-500">{v.type} · Vào lúc {v.inAt}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleFindVehicleForOut(v.plate)}
                    className="px-2.5 py-1.5 bg-[#D4F069] hover:bg-[#C4E35A] text-[#123B46] text-xs font-bold rounded-lg transition-colors"
                  >
                    Xuất xe
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= SCREEN: AUDIT CHECK ================= */}
        {b2bScreen === 'audit' && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2bScreen('home')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Trang chủ</span>
              </button>
              <h2 className="text-xs font-bold text-slate-700">Đối soát ca trực (Audit)</h2>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[11px] text-slate-500 block">Số xe trên hệ thống ParkEasy:</span>
                <span className="text-2xl font-black text-[#123B46]">
                  {staffLot.cap - staffLot.free} <span className="text-xs font-normal text-slate-500">xe</span>
                </span>
                <span className="text-[10px] text-slate-400 block">
                  (Sức chứa: {staffLot.cap} chỗ - {staffLot.free} chỗ trống)
                </span>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Nhập số xe đếm thực tế ngoài bãi:
                </label>
                <input
                  type="number"
                  value={auditPhysicalCount}
                  onChange={(e) => setAuditPhysicalCount(e.target.value)}
                  className="w-full px-3 py-2 text-base font-black bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
                <span className="text-[10px] text-slate-500 block mt-1">
                  Theo quy trình đề án QTKN (Bảng 4.8): Ngưỡng sai số an toàn là dưới 5%.
                </span>
              </div>

              <button
                onClick={() => {
                  const val = Number(auditPhysicalCount);
                  const res = performAuditCount(val);
                  setAuditResult(res);
                }}
                className="w-full py-2.5 bg-[#123B46] hover:bg-[#1A4D5B] text-white font-bold rounded-xl"
              >
                Kiểm tra đối soát
              </button>

              {auditResult && (
                <div className={`p-3 rounded-xl border text-xs space-y-1 ${auditResult.isWarning ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-emerald-50 border-emerald-200 text-emerald-900'}`}>
                  <p className="font-bold flex items-center gap-1.5">
                    {auditResult.isWarning ? <ShieldAlert className="w-4 h-4 text-amber-600" /> : <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                    <span>{auditResult.isWarning ? 'Cảnh báo lệch > 5%' : 'Đối soát đạt chuẩn!'}</span>
                  </p>
                  <p className="text-[11px]">
                    Chênh lệch: {auditResult.discrepancy} xe ({auditResult.discrepancyPercent.toFixed(1)}%).
                    {auditResult.isWarning ? ' Vui lòng đối soát lại nhật ký xe vào/ra.' : ' Dữ liệu đồng bộ tin cậy.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================= SCREEN: REVENUE & STATS ================= */}
        {b2bScreen === 'revenue' && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2bScreen('home')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Trang chủ</span>
              </button>
              <h2 className="text-xs font-bold text-slate-700">Báo cáo doanh thu thời gian thực</h2>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="bg-gradient-to-br from-[#123B46] to-[#1A4D5B] text-white p-3.5 rounded-xl space-y-1">
                <span className="text-[11px] text-slate-300">Tổng doanh thu ca trực hôm nay:</span>
                <span className="text-2xl font-black text-[#D4F069] block">
                  {formatMoney(todayCashRevenue + todayDigitalRevenue)}
                </span>
                <span className="text-[10px] text-slate-300">
                  Tương đương {Math.round((todayCashRevenue + todayDigitalRevenue) / staffLot.priceDay)} lượt xe
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">Tiền mặt:</span>
                  <span className="text-sm font-extrabold text-slate-800">{formatMoney(todayCashRevenue)}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">VietQR / Số:</span>
                  <span className="text-sm font-extrabold text-emerald-700">{formatMoney(todayDigitalRevenue)}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
                <span className="font-bold text-slate-700 block">Chỉ số mô hình SaaS (Gói 398.000đ/tháng):</span>
                <p className="text-[11px] text-slate-600">
                  Doanh thu ước tính bãi: ~17.280.000 đ/tháng. Phí phần mềm ParkEasy chỉ chiếm ~2,3% doanh thu bãi, giúp chủ bãi hoàn toàn yên tâm lợi nhuận.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 3. Bottom Tabs for B2B Staff */}
      <div className="bg-white border-t border-slate-200 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] px-4 flex items-center justify-around text-xs shrink-0 z-20">
        <button
          onClick={() => setB2bScreen('home')}
          className={`flex flex-col items-center gap-0.5 ${b2bScreen === 'home' || b2bScreen === 'plate-in' || b2bScreen === 'plate-out' ? 'text-[#123B46] font-bold' : 'text-slate-400 font-medium'}`}
        >
          <HomeTabIcon className="w-4 h-4" />
          <span>Trực cổng</span>
        </button>

        <button
          onClick={() => setB2bScreen('parked-list')}
          className={`flex flex-col items-center gap-0.5 ${b2bScreen === 'parked-list' ? 'text-[#123B46] font-bold' : 'text-slate-400 font-medium'}`}
        >
          <Car className="w-4 h-4" />
          <span>Trong bãi</span>
        </button>

        <button
          onClick={() => setB2bScreen('audit')}
          className={`flex flex-col items-center gap-0.5 ${b2bScreen === 'audit' ? 'text-[#123B46] font-bold' : 'text-slate-400 font-medium'}`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Đối soát</span>
        </button>

        <button
          onClick={() => setB2bScreen('revenue')}
          className={`flex flex-col items-center gap-0.5 ${b2bScreen === 'revenue' ? 'text-[#123B46] font-bold' : 'text-slate-400 font-medium'}`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Doanh thu</span>
        </button>
      </div>
    </div>
  );
};

// Simple icon wrapper
const HomeTabIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
    <polyline points="9 22 9 12 15 12 15 22"/>
  </svg>
);
