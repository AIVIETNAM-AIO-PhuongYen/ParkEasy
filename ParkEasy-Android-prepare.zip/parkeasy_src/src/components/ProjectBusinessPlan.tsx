import React, { useState } from 'react';
import { 
  PROJECT_TEAM_MEMBERS, 
  ADVISOR_INFO 
} from '../data/initialData';
import {
  FileText,
  Target,
  Award,
  Users,
  TrendingUp,
  DollarSign,
  ShieldCheck,
  CheckCircle2,
  PieChart,
  Layers,
  ArrowRight,
  ExternalLink,
  ChevronDown,
  Building2,
  Briefcase,
  Zap,
  BadgeAlert
} from 'lucide-react';

export const ProjectBusinessPlan: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'brand' | 'market' | 'canvas' | 'financial' | 'team' | 'harvest'>('brand');

  return (
    <div className="py-6 px-4 sm:px-6 max-w-7xl mx-auto space-y-6">
      
      {/* Title & Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full bg-[#123B46] text-[#D4F069]">
              Học phần Khởi nghiệp kinh doanh (BUS1125)
            </span>
            <span className="text-[10px] text-slate-500 font-medium">Trường ĐH Kinh tế – Luật (ĐHQG TP.HCM)</span>
          </div>
          <h1 className="text-xl font-black text-[#123B46] mt-1.5 flex items-center gap-2">
            Đề Án Khởi Nghiệp: Dự Án ParkEasy
          </h1>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
            Giải pháp tìm kiếm chỗ đỗ xe máy thời gian thực và quản lý bãi đỗ số hóa 0đ phần cứng quanh tuyến Metro số 1 & các trường đại học tại TP.HCM.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-3 bg-[#EAF7F5] rounded-2xl border border-[#20B7A6]/30 text-center">
            <span className="text-xs text-slate-500 block">Vốn khởi điểm:</span>
            <span className="text-sm font-extrabold text-[#123B46]">20.000.000 đ</span>
          </div>
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-center">
            <span className="text-xs text-slate-500 block">Hòa vốn dự kiến:</span>
            <span className="text-sm font-extrabold text-emerald-800">Cuối Năm 1</span>
          </div>
        </div>
      </div>

      {/* Nav Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-b border-slate-200">
        {[
          { id: 'brand', label: '1. Nhận diện & Cốt lõi', icon: <Award className="w-3.5 h-3.5" /> },
          { id: 'market', label: '2. Thị trường & Nỗi đau', icon: <Target className="w-3.5 h-3.5" /> },
          { id: 'canvas', label: '3. Mô hình Canvas (9 khối)', icon: <Layers className="w-3.5 h-3.5" /> },
          { id: 'financial', label: '4. Kế hoạch tài chính 3 năm', icon: <TrendingUp className="w-3.5 h-3.5" /> },
          { id: 'team', label: '5. Đội ngũ & Cố vấn UEL', icon: <Users className="w-3.5 h-3.5" /> },
          { id: 'harvest', label: '6. Chiến lược M&A & IPO', icon: <Building2 className="w-3.5 h-3.5" /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSection(tab.id as any)}
            className={`flex items-center gap-1.5 px-3.5 py-2 font-bold rounded-t-xl transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeSection === tab.id
                ? 'border-[#123B46] text-[#123B46] bg-white shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* ================= SECTION 1: BRAND IDENTITY & CORE VALUES ================= */}
      {activeSection === 'brand' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Brand Logo & Naming */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="font-extrabold text-sm text-[#123B46] flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#20B7A6]"></span>
                <span>Tên thương hiệu & Biểu tượng Logo</span>
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                <strong>ParkEasy</strong> được ghép từ <em>Park</em> (đỗ xe) và <em>Easy</em> (dễ dàng), thể hiện định hướng cung cấp giải pháp giúp việc tìm kiếm chỗ đỗ xe và quản lý bãi xe trở nên thuận tiện, đơn giản hơn thông qua công nghệ số.
              </p>
              
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#123B46] via-[#20B7A6] to-[#D4F069] flex items-center justify-center text-white font-black text-2xl shadow-sm shrink-0">
                  PE
                </div>
                <div>
                  <h4 className="font-black text-base text-[#123B46]">ParkEasy</h4>
                  <p className="text-xs font-semibold text-[#20B7A6]">Lựa chọn cho hành trình dễ dàng hơn</p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Biểu tượng kết hợp chữ P (Park) + E (Easy) lồng ghép hình ảnh định vị bản đồ (Pin map icon).
                  </p>
                </div>
              </div>
            </div>

            {/* Color Palette */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="font-extrabold text-sm text-[#123B46] flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#D4F069]"></span>
                <span>Bộ nhận diện màu sắc chuẩn (Brand Colors)</span>
              </h3>
              <p className="text-xs text-slate-600">
                Bộ màu quy định trong tài liệu đề án (Mục 2.1.1.2) với sự phân cấp ý nghĩa rõ rệt:
              </p>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl border border-slate-200 bg-[#123B46] text-white">
                  <span className="font-mono text-[10px] block opacity-80">Màu chủ đạo (Teal)</span>
                  <span className="font-extrabold text-sm block">#123B46</span>
                  <span className="text-[10px] opacity-90 block mt-0.5">Tin cậy, ổn định, chuyên nghiệp</span>
                </div>

                <div className="p-2.5 rounded-xl border border-slate-200 bg-[#20B7A6] text-[#123B46]">
                  <span className="font-mono text-[10px] block opacity-80">Màu bổ trợ (Mint)</span>
                  <span className="font-extrabold text-sm block">#20B7A6</span>
                  <span className="text-[10px] opacity-90 block mt-0.5">Linh hoạt, đổi mới, gần gũi</span>
                </div>

                <div className="p-2.5 rounded-xl border border-slate-200 bg-[#D4F069] text-[#123B46]">
                  <span className="font-mono text-[10px] block opacity-80">Màu nhấn (Lime)</span>
                  <span className="font-extrabold text-sm block">#D4F069</span>
                  <span className="text-[10px] opacity-90 block mt-0.5">Nổi bật, thu hút thị giác, CTA</span>
                </div>

                <div className="p-2.5 rounded-xl border border-slate-200 bg-[#000000] text-white">
                  <span className="font-mono text-[10px] block opacity-80">Màu nền đen (Black)</span>
                  <span className="font-extrabold text-sm block">#000000</span>
                  <span className="text-[10px] opacity-90 block mt-0.5">Tương phản cao, phong cách công nghệ</span>
                </div>
              </div>
            </div>
          </div>

          {/* 5 Core Values */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h3 className="font-extrabold text-sm text-[#123B46]">5 Giá trị cốt lõi của ParkEasy (Mục 2.1.2.3)</h3>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-[#123B46] block text-xs">1. Thuận tiện</span>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Dùng ngay trên Zalo Mini App không cần cài thêm app. Nhân viên bãi thao tác không quá 3 chạm.
                </p>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-[#123B46] block text-xs">2. Dữ liệu thật</span>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Số chỗ trống đến từ từng lượt xe vào/ra thực tế, kèm thời gian cập nhật minh bạch.
                </p>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-[#123B46] block text-xs">3. Đồng hành bãi nhỏ</span>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Thiết kế cho người không rành công nghệ, chạy mượt trên smartphone sẵn có và chế độ mất mạng.
                </p>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-[#123B46] block text-xs">4. Đổi mới công nghệ</span>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Cập nhật thời gian thực, trợ lý AI gợi ý bãi tối ưu, thanh toán VietQR động không tiền mặt.
                </p>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-[#123B46] block text-xs">5. Tối ưu chi phí</span>
                <p className="text-[11px] text-slate-500 leading-normal">
                  0đ chi phí đầu tư phần cứng chuyên dụng, tận dụng hệ sinh thái có sẵn giúp bãi nhỏ dễ chấp nhận.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION 2: MARKET ANALYSIS & PROBLEM ================= */}
      {activeSection === 'market' && (
        <div className="space-y-6">
          {/* Key Market Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] text-slate-500 block">Số xe máy tại TP.HCM:</span>
              <span className="text-xl font-black text-[#123B46] mt-0.5 block">8.6 – 11 triệu xe</span>
              <span className="text-[10px] text-slate-400 mt-1 block">Phương tiện di chuyển chủ đạo</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] text-slate-500 block">Hành khách Metro 1:</span>
              <span className="text-xl font-black text-emerald-800 mt-0.5 block">53.000 lượt/ngày</span>
              <span className="text-[10px] text-slate-400 mt-1 block">18.95 triệu lượt năm đầu tiên</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] text-slate-500 block">Người dùng Zalo hàng tháng:</span>
              <span className="text-xl font-black text-[#123B46] mt-0.5 block">81.3 triệu người</span>
              <span className="text-[10px] text-slate-400 mt-1 block">2.2 tỷ tin nhắn gửi đi mỗi ngày</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] text-slate-500 block">Khung giá trần QĐ 35:</span>
              <span className="text-xl font-black text-emerald-800 mt-0.5 block">4.000 – 6.000 đ</span>
              <span className="text-[10px] text-slate-400 mt-1 block">Phạt 10-20 triệu nếu thu vượt mức</span>
            </div>
          </div>

          {/* Pain points of B2C and B2B */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5 text-xs">
              <h3 className="font-extrabold text-sm text-[#123B46]">Nỗi đau của Người đi xe máy (B2C)</h3>
              <ul className="space-y-1.5 text-slate-600 text-[11px] list-disc list-inside">
                <li>Chạy lòng vòng tìm bãi đỗ xe quanh ga Metro gây trễ giờ làm, lỡ tàu, tốn xăng giờ cao điểm.</li>
                <li>Các bãi xe chính thức tại Ga ĐHQG, Thủ Đức thường xuyên cháy chỗ từ 7h - 8h sáng.</li>
                <li>Bãi tự phát thu giá chặt chém từ 10.000đ/lượt, không đảm bảo an toàn PCCC, sợ trầy xước mất cắp.</li>
                <li>Ngại tải thêm app mới vì dung lượng bộ nhớ đầy (App fatigue).</li>
              </ul>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2.5 text-xs">
              <h3 className="font-extrabold text-sm text-[#123B46]">Nỗi đau của Chủ bãi & Nhân viên (B2B)</h3>
              <ul className="space-y-1.5 text-slate-600 text-[11px] list-disc list-inside">
                <li>Quản lý bằng sổ tay và thẻ giấy dễ nhầm lẫn, rách nát, mất thẻ, nguy cơ thất thoát doanh thu.</li>
                <li>Không biết được doanh thu thực tế từng ca trực, khó kiểm soát nhân viên ca đêm.</li>
                <li>Chi phí lắp đặt hệ thống barrier máy quẹt thẻ từ chuyên dụng quá đắt đỏ (hàng chục đến hàng trăm triệu).</li>
                <li>Nhân viên lớn tuổi ngại sử dụng phần mềm phức tạp, sợ làm chậm luồng xe vào cổng bãi.</li>
              </ul>
            </div>
          </div>

          {/* Competitive Matrix */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h3 className="font-extrabold text-sm text-[#123B46]">Ma trận so sánh cạnh tranh (Bảng 3.6 & 2.9)</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] text-slate-600">
                    <th className="py-2 px-3">Tiêu chí</th>
                    <th className="py-2 px-3">Bãi truyền thống</th>
                    <th className="py-2 px-3">Google Maps</th>
                    <th className="py-2 px-3">My Parking / iParking</th>
                    <th className="py-2 px-3 text-[#123B46] font-bold bg-[#EAF7F5]">ParkEasy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-[11px]">
                  <tr>
                    <td className="py-2 px-3 font-semibold">Đối tượng phương tiện</td>
                    <td className="py-2 px-3 text-slate-500">Mọi loại</td>
                    <td className="py-2 px-3 text-slate-500">Mọi loại</td>
                    <td className="py-2 px-3 text-slate-500">Ô tô, đỗ lòng đường</td>
                    <td className="py-2 px-3 font-bold text-[#123B46] bg-[#EAF7F5]">Xe máy, bãi tư nhân nhỏ quanh Metro</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-semibold">Chỗ trống Real-time</td>
                    <td className="py-2 px-3 text-red-600">Không có</td>
                    <td className="py-2 px-3 text-red-600">Không có</td>
                    <td className="py-2 px-3 text-amber-700">Chỉ điểm đỗ thí điểm</td>
                    <td className="py-2 px-3 font-bold text-emerald-800 bg-[#EAF7F5]">Có, cập nhật từ lượt xe thật</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-semibold">Kênh tiếp cận khách</td>
                    <td className="py-2 px-3 text-slate-500">Biển vỉa hè</td>
                    <td className="py-2 px-3 text-slate-500">Google App</td>
                    <td className="py-2 px-3 text-red-600">Bắt buộc tải app riêng</td>
                    <td className="py-2 px-3 font-bold text-[#123B46] bg-[#EAF7F5]">Zalo Mini App (Không cần cài)</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-semibold">Chi phí phần cứng chủ bãi</td>
                    <td className="py-2 px-3 text-slate-500">Thẻ giấy / Phấn</td>
                    <td className="py-2 px-3 text-slate-500">Không hỗ trợ</td>
                    <td className="py-2 px-3 text-red-600">Cần camera / thiết bị riêng</td>
                    <td className="py-2 px-3 font-bold text-emerald-800 bg-[#EAF7F5]">0đ (Dùng chính smartphone sẵn có)</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-semibold">Vé tháng & Thanh toán số</td>
                    <td className="py-2 px-3 text-slate-500">Tiền mặt tại quầy</td>
                    <td className="py-2 px-3 text-slate-500">Không có</td>
                    <td className="py-2 px-3 text-slate-500">Có (Tạm dừng/hạn chế)</td>
                    <td className="py-2 px-3 font-bold text-[#123B46] bg-[#EAF7F5]">VietQR tự động kích hoạt vé tháng</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION 3: BUSINESS MODEL CANVAS ================= */}
      {activeSection === 'canvas' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#20B7A6] tracking-wider">Mục 3.5</span>
              <h3 className="font-extrabold text-sm text-[#123B46]">Mô Hình Kinh Doanh 9 Khối (Business Model Canvas)</h3>
            </div>
            <span className="text-xs text-slate-500">Osterwalder & Pigneur (2010)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
            {/* 1. Key Partners */}
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2">
              <span className="font-extrabold text-[#123B46] text-xs block">1. Đối tác chính</span>
              <ul className="text-[11px] text-slate-600 space-y-1">
                <li>• Chủ bãi xe & nhân viên giữ xe tư nhân</li>
                <li>• Ban Quản lý Đường sắt đô thị (Metro 1)</li>
                <li>• Zalo Platform (Zalo Mini App Store)</li>
                <li>• Cổng thanh toán VietQR / ZaloPay / MBBank</li>
                <li>• Đơn vị đối tác dịch vụ rửa xe, bảo dưỡng lân cận</li>
              </ul>
            </div>

            {/* 2. Key Activities & Resources */}
            <div className="space-y-3">
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <span className="font-extrabold text-[#123B46] text-xs block">2. Hoạt động chính</span>
                <ul className="text-[11px] text-slate-600 space-y-1">
                  <li>• Phát triển Mini App & B2B SaaS</li>
                  <li>• Đào tạo nhân viên giữ xe & thẩm định bãi</li>
                  <li>• Đối soát dữ liệu chỗ trống & chống thất thoát</li>
                  <li>• Marketing du kích quanh ga Metro</li>
                </ul>
              </div>

              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <span className="font-extrabold text-[#123B46] text-xs block">3. Nguồn lực chính</span>
                <ul className="text-[11px] text-slate-600 space-y-1">
                  <li>• Thuật toán gợi ý bãi xe AI</li>
                  <li>• Hạ tầng Cloud Serverless (Firebase)</li>
                  <li>• Dữ liệu vận hành bãi thời gian thực</li>
                  <li>• Đội ngũ kỹ thuật & thực địa UEL</li>
                </ul>
              </div>
            </div>

            {/* 3. Value Propositions */}
            <div className="bg-[#EAF7F5] p-3.5 rounded-2xl border border-[#20B7A6]/40 space-y-2">
              <span className="font-extrabold text-[#123B46] text-xs block">4. Giá trị đề xuất (USP)</span>
              <div className="space-y-2 text-[11px]">
                <div>
                  <strong className="text-[#123B46] block">Cho người gửi xe (B2C):</strong>
                  <p className="text-slate-600 mt-0.5">Biết trước chỗ trống real-time, giá minh bạch, trợ lý AI gợi ý bãi, dùng ngay trong Zalo không cần tải app.</p>
                </div>
                <div>
                  <strong className="text-[#123B46] block">Cho chủ bãi (B2B):</strong>
                  <p className="text-slate-600 mt-0.5">Bật SaaS quản lý 0đ phần cứng trên smartphone, tăng khách gửi xe, minh bạch doanh thu và chống thất thoát.</p>
                </div>
              </div>
            </div>

            {/* 4. Customer Relationships & Channels */}
            <div className="space-y-3">
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <span className="font-extrabold text-[#123B46] text-xs block">5. Quan hệ khách hàng</span>
                <ul className="text-[11px] text-slate-600 space-y-1">
                  <li>• Tự phục vụ qua Zalo Mini App</li>
                  <li>• Hỗ trợ B2B trực tiếp tại bãi</li>
                  <li>• Đào tạo 1-1 cho bảo vệ</li>
                  <li>• Cảnh báo sai lệch cộng đồng</li>
                </ul>
              </div>

              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <span className="font-extrabold text-[#123B46] text-xs block">6. Kênh phân phối</span>
                <ul className="text-[11px] text-slate-600 space-y-1">
                  <li>• Zalo Mini App Store</li>
                  <li>• Mã QR dán tại cổng bãi & nhà ga</li>
                  <li>• Đội ngũ phát triển đối tác B2B Sales</li>
                </ul>
              </div>
            </div>

            {/* 5. Customer Segments */}
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2">
              <span className="font-extrabold text-[#123B46] text-xs block">7. Phân khúc khách hàng</span>
              <ul className="text-[11px] text-slate-600 space-y-1.5">
                <li>
                  <strong className="text-[#123B46]">B2C:</strong> Sinh viên ĐHQG, nhân viên văn phòng đi Metro số 1, khách vãng lai đi mua sắm.
                </li>
                <li>
                  <strong className="text-[#123B46]">B2B:</strong> Chủ bãi giữ xe tư nhân quanh các ga Metro và trường đại học; nhân viên trông xe tại cổng.
                </li>
              </ul>
            </div>
          </div>

          {/* Cost Structure and Revenue Streams */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-xs">
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1">
              <span className="font-extrabold text-[#123B46] block">8. Cấu trúc chi phí (Cost Structure)</span>
              <p className="text-[11px] text-slate-600">
                Hạ tầng Cloud Firebase & Google Maps API · Marketing & In ấn mã QR tại bãi · Thù lao đội ngũ sáng lập & nhân sự thực địa · Pháp lý và bảo vệ dữ liệu cá nhân.
              </p>
            </div>

            <div className="bg-[#EAF7F5] p-3 rounded-2xl border border-[#20B7A6]/40 space-y-1">
              <span className="font-extrabold text-[#123B46] block">9. Dòng doanh thu (3 Trụ cột)</span>
              <p className="text-[11px] text-slate-700">
                ① Thuê bao B2B SaaS (398.000đ/bãi/tháng) · ② Phí tiện ích vé tháng B2C (15.000đ/vé) · ③ Quảng cáo dịch vụ lân cận Hyper-local (rửa xe, sửa xe quanh bãi).
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION 4: 3-YEAR FINANCIAL FORECAST ================= */}
      {activeSection === 'financial' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#20B7A6] tracking-wider">Mục VI – Báo cáo tài chính</span>
            <h3 className="font-extrabold text-sm text-[#123B46]">Kế Hoạch & Dự Báo Tài Chính (12 – 36 Tháng)</h3>
            <p className="text-xs text-slate-500 mt-0.5">Số liệu được tính toán dựa trên mô hình khởi nghiệp tinh gọn (Đơn vị tính: Nghìn VNĐ)</p>
          </div>

          {/* 3 Pillars Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[11px] text-slate-500 block">Năm 1: Kiểm chứng mô hình</span>
              <span className="text-xl font-black text-[#123B46]">11.970.000 đ</span>
              <p className="text-[10px] text-slate-500">100% từ SaaS B2B (2,5 bãi trả phí bình quân). Hòa vốn sau 3 tháng thử nghiệm.</p>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[11px] text-slate-500 block">Năm 2: Mở rộng mạng lưới</span>
              <span className="text-xl font-black text-[#123B46]">106.632.000 đ</span>
              <p className="text-[10px] text-slate-500">14 bãi đối tác. Kích hoạt thêm vé tháng B2C (25,2 tr) và quảng cáo bãi (14,4 tr).</p>
            </div>

            <div className="bg-[#EAF7F5] p-3.5 rounded-2xl border border-[#20B7A6]/50 space-y-1">
              <span className="text-[11px] text-slate-600 block">Năm 3: Tối ưu hóa & Tăng tốc</span>
              <span className="text-xl font-black text-emerald-800">325.038.000 đ</span>
              <p className="text-[10px] text-slate-600">33 bãi trả phí. B2C & tiện ích vươn lên chiếm 51%, lợi nhuận sau thuế ~50 triệu.</p>
            </div>
          </div>

          {/* Income Statement Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] text-slate-600">
                  <th className="py-2.5 px-3">Chỉ tiêu tài chính</th>
                  <th className="py-2.5 px-3">Năm 1</th>
                  <th className="py-2.5 px-3">Năm 2</th>
                  <th className="py-2.5 px-3">Năm 3</th>
                  <th className="py-2.5 px-3">Ghi chú vận hành</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[11px]">
                <tr className="font-bold">
                  <td className="py-2 px-3 text-[#123B46]">1. Doanh thu thuần</td>
                  <td className="py-2 px-3 text-[#123B46]">11.970</td>
                  <td className="py-2 px-3 text-[#123B46]">106.632</td>
                  <td className="py-2 px-3 text-[#123B46]">325.038</td>
                  <td className="py-2 px-3 text-slate-500">SaaS B2B + Vé tháng B2C + Quảng cáo</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 pl-6 text-slate-600">- Doanh thu SaaS B2B (398k/bãi/tháng)</td>
                  <td className="py-2 px-3">11.970</td>
                  <td className="py-2 px-3">67.032</td>
                  <td className="py-2 px-3">157.998</td>
                  <td className="py-2 px-3 text-slate-500">2.5 bãi → 14 bãi → 33 bãi trả phí</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 pl-6 text-slate-600">- Doanh thu vé tháng B2C (15k/vé)</td>
                  <td className="py-2 px-3">0</td>
                  <td className="py-2 px-3">25.200</td>
                  <td className="py-2 px-3">95.040</td>
                  <td className="py-2 px-3 text-slate-500">Kích hoạt giai đoạn 2 qua VietQR</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 pl-6 text-slate-600">- Quảng cáo & tiện ích bổ trợ</td>
                  <td className="py-2 px-3">0</td>
                  <td className="py-2 px-3">14.400</td>
                  <td className="py-2 px-3">72.000</td>
                  <td className="py-2 px-3 text-slate-500">Đối tác rửa xe, sửa xe quanh ga</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 text-slate-700">2. Giá vốn hàng bán (Hạ tầng, API)</td>
                  <td className="py-2 px-3 text-red-600">-1.800</td>
                  <td className="py-2 px-3 text-red-600">-9.600</td>
                  <td className="py-2 px-3 text-red-600">-28.800</td>
                  <td className="py-2 px-3 text-slate-500">Firebase Cloud, Zalo Mini App, SSL</td>
                </tr>
                <tr className="font-semibold bg-slate-50/50">
                  <td className="py-2 px-3 text-slate-800">3. Lợi nhuận gộp (Biên LN &gt; 85%)</td>
                  <td className="py-2 px-3 text-slate-900">10.170 (85%)</td>
                  <td className="py-2 px-3 text-slate-900">97.032 (91%)</td>
                  <td className="py-2 px-3 text-slate-900">296.238 (91%)</td>
                  <td className="py-2 px-3 text-slate-500">Mô hình SaaS không gánh chi phí thiết bị</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 text-slate-700">4. Chi phí hoạt động & Nhân sự</td>
                  <td className="py-2 px-3 text-red-600">-9.700</td>
                  <td className="py-2 px-3 text-red-600">-81.000</td>
                  <td className="py-2 px-3 text-red-600">-234.000</td>
                  <td className="py-2 px-3 text-slate-500">Marketing, QR, lương nhân sự thực địa</td>
                </tr>
                <tr className="font-extrabold bg-[#EAF7F5]">
                  <td className="py-2 px-3 text-emerald-900">5. Lợi nhuận sau thuế (Thuế 20%)</td>
                  <td className="py-2 px-3 text-emerald-900">376</td>
                  <td className="py-2 px-3 text-emerald-900">12.826</td>
                  <td className="py-2 px-3 text-emerald-900">49.790</td>
                  <td className="py-2 px-3 text-emerald-800 font-semibold">Tăng trưởng bền vững, bảo toàn vốn</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= SECTION 5: TEAM & ADVISOR ================= */}
      {activeSection === 'team' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#20B7A6] tracking-wider">Mục 5.1 & 5.2</span>
                <h3 className="font-extrabold text-sm text-[#123B46]">Đội Ngũ Sáng Lập & Ban Cố Vấn Chuyên Môn</h3>
              </div>
              <span className="text-xs text-slate-500">5 Cổ đông sáng lập · Tỷ lệ vốn 20%/người</span>
            </div>

            {/* Advisor spotlight */}
            <div className="bg-gradient-to-r from-[#123B46] to-[#1A4D5B] text-white p-4 rounded-2xl shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#20B7A6] text-[#123B46] font-black text-lg flex items-center justify-center shrink-0 shadow-sm">
                  PTT
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-sm text-white">{ADVISOR_INFO.name}</h4>
                    <span className="text-[10px] bg-[#D4F069] text-[#123B46] px-1.5 py-0.2 rounded font-bold">
                      Cố vấn
                    </span>
                  </div>
                  <p className="text-xs text-slate-200">{ADVISOR_INFO.title} – {ADVISOR_INFO.institution}</p>
                  <p className="text-[11px] text-slate-300 mt-1 max-w-xl">{ADVISOR_INFO.description}</p>
                </div>
              </div>
            </div>

            {/* Team Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-2 text-xs">
              {PROJECT_TEAM_MEMBERS.map((member) => (
                <div key={member.name} className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-[#123B46] text-[#D4F069] font-bold text-xs flex items-center justify-center shrink-0">
                      {member.avatar}
                    </div>
                    <div>
                      <h4 className="font-extrabold text-xs text-[#123B46]">{member.name}</h4>
                      <span className="text-[11px] text-emerald-700 font-semibold">{member.role}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-600 font-medium">Trọng tâm: {member.focus}</p>
                  <p className="text-[10px] text-slate-500 leading-normal">{member.duties}</p>
                  
                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-400">
                    <span>Tỷ lệ cổ phần:</span>
                    <strong className="text-slate-700">{member.equity}</strong>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION 6: HARVEST & M&A ================= */}
      {activeSection === 'harvest' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#20B7A6] tracking-wider">Mục VIII – Chiến lược thu hoạch</span>
            <h3 className="font-extrabold text-sm text-[#123B46]">Định Hướng M&A (Sáp Nhập) & Lộ Trình Dài Hạn</h3>
            <p className="text-xs text-slate-500 mt-0.5">Hai kịch bản thoái vốn tiềm năng trong 3 – 5 năm khi đạt quy mô bao phủ các trạm Metro</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
              <span className="text-xs font-bold text-[#123B46] flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-[#20B7A6]" />
                <span>Kịch bản 1: M&A với Siêu ứng dụng (Grab, Be Group)</span>
              </span>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Các siêu ứng dụng di chuyển tìm kiếm mảnh ghép để khép kín hành trình đa phương thức (multimodal transit). Mua lại ParkEasy giúp họ sở hữu ngay mạng lưới điểm đỗ dặm đầu/dặm cuối (First Mile / Last Mile) quanh các ga Metro mà không cần xây dựng từ đầu.
              </p>
              <div className="bg-white p-2 rounded-lg border border-slate-200 text-[10px] text-slate-500">
                Định giá theo ARR Multiple: 4x – 7x doanh thu mảng B2B SaaS.
              </div>
            </div>

            <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
              <span className="text-xs font-bold text-[#123B46] flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-700" />
                <span>Kịch bản 2: Bất động sản đô thị (Vingroup, Masterise, SonKim)</span>
              </span>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Nhu cầu số hóa hạ tầng tĩnh tại các tổ hợp đại đô thị, trung tâm thương mại và hệ thống trạm sạc xe điện. Nền tảng B2B SaaS giúp chuẩn hóa công nghệ vận hành cho hàng chục ngàn vị trí đỗ xe theo chuẩn Smart City.
              </p>
              <div className="bg-white p-2 rounded-lg border border-slate-200 text-[10px] text-slate-500">
                Định giá dựa trên quy mô mạng lưới độc quyền & lượng người dùng hoạt động (MAU).
              </div>
            </div>
          </div>

          <div className="bg-[#EAF7F5] p-4 rounded-2xl border border-[#20B7A6]/50 space-y-2 text-xs">
            <h4 className="font-extrabold text-[#123B46]">Lộ trình IPO dài hạn (Năm thứ 5 – 6)</h4>
            <p className="text-[11px] text-slate-700 leading-relaxed">
              Mục tiêu niêm yết trên sàn HOSE hoặc UPCoM: Kết nối tối thiểu 1.500 bãi xe đối tác tại TP.HCM & Hà Nội, đạt 2 triệu người dùng hoạt động thường xuyên, vận hành hơn 80% công suất điểm đỗ tại các ga Metro. Doanh thu tối thiểu 150 – 200 tỷ VNĐ/năm với biên lợi nhuận ròng trên 18%.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
