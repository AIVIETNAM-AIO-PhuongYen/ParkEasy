import React, { useState } from 'react';
import { useParkEasy } from '../context/ParkEasyContext';
import { ParkingLot, MonthlyPassOption } from '../types/parkeasy';
import { MONTHLY_PASS_OPTIONS, METRO_STATIONS } from '../data/initialData';
import {
  Search,
  Navigation,
  MapPin,
  Clock,
  Shield,
  CreditCard,
  QrCode,
  Sparkles,
  ChevronRight,
  ArrowLeft,
  X,
  Check,
  AlertTriangle,
  Flame,
  ThumbsUp,
  ThumbsDown,
  Info,
  ExternalLink,
  Calendar,
  CheckCircle2,
  Ticket
} from 'lucide-react';

export const B2CApp: React.FC<{ isEmbedded?: boolean }> = ({ isEmbedded = false }) => {
  const {
    parkingLots,
    selectedLotId,
    setSelectedLotId,
    activeLot,
    selectedStationFilter,
    setSelectedStationFilter,
    userMonthlyPasses,
    purchaseMonthlyPass,
    submitLotCrowdReport,
    addToast,
    getAiRecommendation,
    setViewMode
  } = useParkEasy();

  // Navigation states inside Mini App
  const [b2cScreen, setB2cScreen] = useState<'home' | 'detail' | 'buy-pass' | 'payment' | 'my-passes'>('home');
  const [activeTab, setActiveTab] = useState<'lots' | 'passes'>('lots');
  const [sortOption, setSortOption] = useState<'dist' | 'free' | 'price'>('dist');
  const [onlyAvailable, setOnlyAvailable] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSlotId, setSelectedSlotId] = useState<'office' | 'full'>('office');

  // Booking / Monthly Pass Form
  const [passFullName, setPassFullName] = useState<string>('Nguyễn Phan Yến Phương');
  const [passPhone, setPassPhone] = useState<string>('0912 345 678');
  const [passPlate, setPassPlate] = useState<string>('59P2-9163');
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);

  // Helper format
  const formatMoney = (n: number) => n.toLocaleString('vi-VN') + ' đ';
  const formatDist = (m: number) => (m >= 1000 ? (m / 1000).toFixed(1) + ' km' : m + ' m');

  const getStatusBadge = (lot: ParkingLot) => {
    if (lot.free === 0) {
      return {
        label: 'Hết chỗ',
        bg: 'bg-red-50 text-red-700 border-red-200',
        dot: 'bg-red-600',
        bar: 'bg-red-500'
      };
    }
    if (lot.free / lot.cap <= 0.15) {
      return {
        label: 'Sắp đầy',
        bg: 'bg-amber-50 text-amber-800 border-amber-200',
        dot: 'bg-amber-500',
        bar: 'bg-amber-500'
      };
    }
    return {
      label: 'Còn chỗ',
      bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      dot: 'bg-emerald-500',
      bar: 'bg-emerald-500'
    };
  };

  // Filter lots
  const filteredLots = parkingLots
    .filter((lot) => {
      if (selectedStationFilter !== 'all' && lot.station !== selectedStationFilter) return false;
      if (onlyAvailable && lot.free <= 0) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return lot.name.toLowerCase().includes(q) || lot.area.toLowerCase().includes(q) || lot.address.toLowerCase().includes(q);
      }
      return true;
    })
    .sort((a, b) => {
      if (sortOption === 'dist') return a.dist - b.dist;
      if (sortOption === 'free') return b.free - a.free;
      if (sortOption === 'price') return a.priceDay - b.priceDay || a.dist - b.dist;
      return 0;
    });

  // AI Recommendation
  const aiRec = getAiRecommendation(sortOption);

  // Selected pass slot option
  const selectedSlot = MONTHLY_PASS_OPTIONS.find((s) => s.id === selectedSlotId) || MONTHLY_PASS_OPTIONS[0];

  const handleStartPassCheckout = () => {
    setB2cScreen('payment');
  };

  const handleConfirmPayment = () => {
    setIsProcessingPayment(true);
    setTimeout(() => {
      setIsProcessingPayment(false);
      purchaseMonthlyPass(activeLot.id, selectedSlotId, passPlate, passFullName, passPhone);
      setB2cScreen('my-passes');
    }, 1200);
  };

  const handleOpenGoogleMaps = (lot: ParkingLot) => {
    addToast(
      'Mở Google Maps chỉ đường',
      `Đang chuyển hướng tọa độ (${lot.coordinates.lat}, ${lot.coordinates.lng}) tới cổng ${lot.name}...`,
      'info'
    );
  };

  // 21x21 QR Code Generator Matrix for simulation
  const generateQrMatrix = (seedStr: string) => {
    const N = 21;
    const matrix: boolean[][] = [];
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      hash = (hash << 5) - hash + seedStr.charCodeAt(i);
      hash |= 0;
    }
    const seed = Math.abs(hash) % 100;

    for (let r = 0; r < N; r++) {
      const row: boolean[] = [];
      for (let c = 0; c < N; c++) {
        // Finder patterns in corners
        const inTopLeft = r <= 6 && c <= 6;
        const inTopRight = r <= 6 && c >= 14;
        const inBottomLeft = r >= 14 && c <= 6;

        if (inTopLeft || inTopRight || inBottomLeft) {
          const rr = inBottomLeft ? r - 14 : r;
          const cc = inTopRight ? c - 14 : c;
          const isBorder = rr === 0 || rr === 6 || cc === 0 || cc === 6;
          const isCenter = rr >= 2 && rr <= 4 && cc >= 2 && cc <= 4;
          row.push(isBorder || isCenter);
        } else {
          // Pseudorandom based on coords & seed
          const val = (r * 7 + c * 13 + r * c * 3 + seed) % 10;
          row.push(val < 4);
        }
      }
      matrix.push(row);
    }
    return matrix;
  };

  return (
    <div className={`flex flex-col bg-[#F4F6F5] text-[#123B46] select-none ${isEmbedded ? 'h-full min-h-0' : 'w-full h-[100dvh] min-h-0'}`}>
      
      {/* 1. Zalo Mini App Navigation Bar */}
      <div className="bg-[#123B46] text-white pt-2.5 pb-3 px-3.5 shrink-0 shadow-sm">
        <div className="flex items-center justify-between text-xs pb-1 text-slate-300">
          <div className="flex items-center gap-1 font-medium">
            <span>08:28</span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px]">
            <span>Zalo Mini App</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#20B7A6] inline-block"></span>
          </div>
        </div>

        <div className="flex items-center justify-between mt-1">
          <div className="flex items-center gap-2">
            {b2cScreen !== 'home' ? (
              <button
                onClick={() => setB2cScreen('home')}
                className="p-1 rounded-full hover:bg-white/10 transition-colors"
                aria-label="Quay lại"
              >
                <ArrowLeft className="w-5 h-5 text-white" />
              </button>
            ) : (
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#20B7A6] to-[#D4F069] flex items-center justify-center font-bold text-xs text-[#123B46]">
                PE
              </div>
            )}
            <div>
              <h1 className="font-bold text-sm leading-tight text-white flex items-center gap-1">
                ParkEasy
                <span className="text-[10px] bg-[#20B7A6] text-[#123B46] px-1 py-0.2 rounded font-semibold">
                  Metro 1
                </span>
              </h1>
              <p className="text-[10px] text-slate-300">Lựa chọn cho hành trình dễ dàng hơn</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-[#0A262E] px-2 py-1 rounded-full border border-white/10 text-[11px] text-slate-300">
              <span className="w-2 h-2 rounded-full bg-[#20B7A6] animate-pulse"></span><span>Real-time</span>
            </div>
            <button onClick={() => setViewMode('b2b')} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#D4F069] text-[#123B46] text-[11px] font-bold shadow-sm active:scale-95" aria-label="Chuyển sang giao diện chủ bãi xe">
              <span>Chủ bãi</span><ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 2. Main Content Area */}
      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain pb-3">
        
        {/* ================= SCREEN: HOME ================= */}
        {b2cScreen === 'home' && (
          <div className="p-3.5 space-y-3.5">
            
            {/* Quick Top Bar: Search & Station Filter */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-200/80 shadow-xs space-y-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Tìm bãi đỗ quanh ga Metro, ĐHQG, Suối Tiên..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#20B7A6]"
                />
              </div>

              {/* Station Quick Selector */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
                <span className="text-[11px] font-semibold text-slate-500 shrink-0">Ga:</span>
                <button
                  onClick={() => setSelectedStationFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium shrink-0 transition-colors ${
                    selectedStationFilter === 'all'
                      ? 'bg-[#123B46] text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Tất cả ga
                </button>
                {METRO_STATIONS.slice(9).map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStationFilter(st.name)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium shrink-0 transition-colors ${
                      selectedStationFilter === st.name
                        ? 'bg-[#123B46] text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {st.name.replace('Ga ', '')}
                  </button>
                ))}
              </div>
            </div>

            {/* AI Recommendation Banner */}
            <div className="bg-gradient-to-r from-[#123B46] to-[#1A4D5B] text-white p-3.5 rounded-2xl shadow-sm border border-[#20B7A6]/30">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#D4F069]">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Trợ lý AI gợi ý bãi tối ưu</span>
                </div>
                <span className="text-[10px] text-slate-300 bg-white/10 px-2 py-0.5 rounded-full">
                  Cập nhật ngay
                </span>
              </div>

              <div className="bg-white/10 backdrop-blur-xs p-2.5 rounded-xl border border-white/10 flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-xs text-white truncate">{aiRec.primaryLot.name}</p>
                  <p className="text-[11px] text-[#D4F069] mt-0.5 font-medium">
                    Còn {aiRec.primaryLot.free} chỗ trống · Cách {formatDist(aiRec.primaryLot.dist)} · {formatMoney(aiRec.primaryLot.priceDay)}/lượt
                  </p>
                  <p className="text-[10px] text-slate-200 mt-1 line-clamp-1 italic">
                    💡 {aiRec.explanation}
                  </p>
                </div>
                <button
                  onClick={() => {
                    setSelectedLotId(aiRec.primaryLot.id);
                    setB2cScreen('detail');
                  }}
                  className="px-3 py-1.5 bg-[#D4F069] hover:bg-[#C5E452] text-[#123B46] text-xs font-bold rounded-lg shrink-0 transition-colors shadow-xs"
                >
                  Xem bãi
                </button>
              </div>

              {/* Sub-backup recommendation */}
              <div className="mt-2 flex items-center justify-between text-[11px] text-slate-300">
                <span>Dự phòng lân cận:</span>
                <button
                  onClick={() => {
                    setSelectedLotId(aiRec.backupLot.id);
                    setB2cScreen('detail');
                  }}
                  className="text-white hover:text-[#D4F069] font-medium underline truncate max-w-[200px]"
                >
                  {aiRec.backupLot.name} (Còn {aiRec.backupLot.free} chỗ)
                </button>
              </div>
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center justify-between gap-1.5 overflow-x-auto pb-1 text-xs">
              <button
                onClick={() => setSortOption('dist')}
                className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
                  sortOption === 'dist'
                    ? 'bg-[#123B46] text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                Gần nhất
              </button>
              <button
                onClick={() => setSortOption('free')}
                className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
                  sortOption === 'free'
                    ? 'bg-[#123B46] text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                Nhiều chỗ
              </button>
              <button
                onClick={() => setSortOption('price')}
                className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
                  sortOption === 'price'
                    ? 'bg-[#123B46] text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                Giá thấp
              </button>
              <button
                onClick={() => setOnlyAvailable(!onlyAvailable)}
                className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all flex items-center gap-1 ${
                  onlyAvailable
                    ? 'bg-[#20B7A6] text-[#123B46] font-semibold'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                {onlyAvailable && <Check className="w-3 h-3" />}
                Chỉ còn chỗ
              </button>
            </div>

            {/* List of Parking Lots */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs px-1 text-slate-500 font-medium">
                <span>Danh sách bãi xe ({filteredLots.length})</span>
                <span>Giá niêm yết chuẩn</span>
              </div>

              {filteredLots.length === 0 ? (
                <div className="bg-white p-6 rounded-2xl text-center border border-slate-200 space-y-2">
                  <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
                  <p className="text-xs font-semibold text-slate-700">Không tìm thấy bãi đỗ phù hợp</p>
                  <p className="text-[11px] text-slate-500">Thử tắt bộ lọc "Chỉ còn chỗ" hoặc tìm theo ga metro khác.</p>
                </div>
              ) : (
                filteredLots.map((lot) => {
                  const badge = getStatusBadge(lot);
                  const occupancyPct = Math.round(((lot.cap - lot.free) / lot.cap) * 100);

                  return (
                    <div
                      key={lot.id}
                      onClick={() => {
                        setSelectedLotId(lot.id);
                        setB2cScreen('detail');
                      }}
                      className="bg-white p-3.5 rounded-2xl border border-slate-200/90 hover:border-[#20B7A6] shadow-xs cursor-pointer transition-all hover:shadow-sm"
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="min-w-0">
                          <h3 className="font-bold text-xs text-[#123B46] truncate flex items-center gap-1.5">
                            {lot.name}
                            {lot.isPartner && (
                              <span className="text-[9px] bg-[#123B46] text-[#D4F069] px-1 py-0.2 rounded font-semibold">
                                Đối tác
                              </span>
                            )}
                          </h3>
                          <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate">{lot.area}</span>
                            <span>·</span>
                            <span className="font-semibold text-slate-700">{formatDist(lot.dist)}</span>
                          </p>
                        </div>

                        {/* Status Badge */}
                        <div className={`px-2.5 py-1 rounded-full text-[11px] font-bold border flex items-center gap-1.5 shrink-0 ${badge.bg}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`}></span>
                          <span>{badge.label}</span>
                        </div>
                      </div>

                      {/* Progress bar of lot capacity */}
                      <div className="space-y-1 mb-2.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-semibold text-[#123B46]">
                            Còn <strong className="text-sm font-extrabold text-[#123B46]">{lot.free}</strong> / {lot.cap} chỗ trống
                          </span>
                          <span className="text-slate-400 text-[10px]">{occupancyPct}% đã đỗ</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-500 ${badge.bar}`}
                            style={{ width: `${occupancyPct}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Card Footer: price, hours, updated time */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-[#123B46] text-xs">
                            {formatMoney(lot.priceDay)}
                            <span className="font-normal text-slate-500 text-[10px]">/lượt</span>
                          </span>
                          <span>·</span>
                          <span>{lot.hours}</span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {lot.lastUpdatedMinutesAgo === 0 ? 'Vừa xong' : `${lot.lastUpdatedMinutesAgo} phút trước`}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* ================= SCREEN: DETAIL ================= */}
        {b2cScreen === 'detail' && (
          <div className="p-3.5 space-y-3.5">
            {/* Top Back Header */}
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2cScreen('home')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46] hover:text-[#20B7A6]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Quay lại danh sách</span>
              </button>
              <span className="text-xs text-slate-500">Mã bãi: #{activeLot.id}</span>
            </div>

            {/* Main Lot Info Card */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="font-bold text-sm text-[#123B46]">{activeLot.name}</h2>
                  <p className="text-xs text-slate-500 mt-0.5">{activeLot.address}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-bold border shrink-0 ${getStatusBadge(activeLot).bg}`}>
                  {getStatusBadge(activeLot).label}
                </div>
              </div>

              {/* Big Capacity Counter */}
              <div className="bg-[#F4F8F7] p-3 rounded-xl border border-[#D7E6E3] flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-600 block">Số chỗ trống thực tế:</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-3xl font-black text-[#123B46]">{activeLot.free}</span>
                    <span className="text-xs text-slate-500 font-medium">/ {activeLot.cap} chỗ</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-slate-500 block">Cự ly đến ga:</span>
                  <span className="text-sm font-bold text-[#123B46]">{formatDist(activeLot.dist)}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">(~2 phút đi bộ)</span>
                </div>
              </div>

              {/* Legal Pricing Table under Quyết định 35/2018/QĐ-UBND */}
              <div className="space-y-1.5 pt-1">
                <span className="text-xs font-bold text-slate-700 block flex items-center justify-between">
                  <span>Bảng giá niêm yết minh bạch:</span>
                  <span className="text-[10px] font-normal text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    QĐ 35/2018 TP.HCM
                  </span>
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">Ban ngày (05:00 - 18:00):</span>
                    <span className="font-extrabold text-[#123B46]">{formatMoney(activeLot.priceDay)}/lượt</span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">Ban đêm (18:00 - 05:00):</span>
                    <span className="font-extrabold text-[#123B46]">{formatMoney(activeLot.priceNight)}/lượt</span>
                  </div>
                </div>
              </div>

              {/* Facilities tags */}
              <div className="flex flex-wrap gap-1.5 pt-1 text-[11px]">
                <span className="flex items-center gap-1 bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                  <Clock className="w-3 h-3 text-slate-500" />
                  {activeLot.hours}
                </span>
                <span className="flex items-center gap-1 bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                  <Shield className="w-3 h-3 text-slate-500" />
                  Giữ qua đêm: {activeLot.night}
                </span>
                <span className="flex items-center gap-1 bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                  <Flame className="w-3 h-3 text-slate-500" />
                  Chuẩn PCCC & Bảo vệ 24/7
                </span>
              </div>
            </div>

            {/* Action Buttons: Directions & Monthly Pass */}
            <div className="space-y-2">
              <button
                onClick={() => handleOpenGoogleMaps(activeLot)}
                className="w-full py-2.5 px-4 bg-[#123B46] hover:bg-[#1A4D5B] text-white text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-2 transition-colors"
              >
                <Navigation className="w-4 h-4 text-[#D4F069]" />
                <span>Chỉ đường tới cổng bãi (Google Maps)</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-300" />
              </button>

              <button
                onClick={() => setB2cScreen('buy-pass')}
                className="w-full py-2.5 px-4 bg-[#20B7A6] hover:bg-[#1AA393] text-[#123B46] text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-2 transition-colors"
              >
                <Calendar className="w-4 h-4" />
                <span>Mua vé tháng giữ chỗ cố định (từ 180.000đ)</span>
              </button>
            </div>

            {/* Community Accuracy Check */}
            <div className="bg-white p-3 rounded-xl border border-slate-200/90 text-xs space-y-2">
              <div className="flex items-center gap-1.5 font-semibold text-slate-700">
                <Info className="w-3.5 h-3.5 text-[#20B7A6]" />
                <span>Bạn đang gửi xe tại bãi này?</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Đóng góp xác thực của bạn giúp số chỗ trống luôn chính xác theo thời gian thực cho cộng đồng.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => submitLotCrowdReport(activeLot.id, true)}
                  className="flex-1 py-1.5 px-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg font-medium text-[11px] flex items-center justify-center gap-1 border border-emerald-200 transition-colors"
                >
                  <ThumbsUp className="w-3 h-3" />
                  <span>Số chỗ chính xác</span>
                </button>
                <button
                  onClick={() => submitLotCrowdReport(activeLot.id, false)}
                  className="flex-1 py-1.5 px-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg font-medium text-[11px] flex items-center justify-center gap-1 border border-amber-200 transition-colors"
                >
                  <ThumbsDown className="w-3 h-3" />
                  <span>Báo sai lệch</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================= SCREEN: BUY PASS ================= */}
        {b2cScreen === 'buy-pass' && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2cScreen('detail')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Chi tiết bãi</span>
              </button>
              <span className="text-xs font-bold text-slate-700">Đăng ký vé tháng</span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div>
                <h3 className="font-bold text-xs text-[#123B46]">{activeLot.name}</h3>
                <p className="text-[11px] text-slate-500">Giữ chỗ đảm bảo theo khung giờ quy định</p>
              </div>

              {/* Slot Options */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-slate-700 block">1. Chọn khung giờ gửi:</span>
                {MONTHLY_PASS_OPTIONS.map((opt) => {
                  const isSelected = selectedSlotId === opt.id;
                  return (
                    <div
                      key={opt.id}
                      onClick={() => setSelectedSlotId(opt.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'border-[#123B46] bg-[#EAF7F5]'
                          : 'border-slate-200 bg-white hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-[#123B46] bg-[#123B46]' : 'border-slate-300'}`}>
                            {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                          </div>
                          <div>
                            <span className="font-bold text-xs text-[#123B46] block">{opt.label}</span>
                            <span className="text-[11px] text-slate-500">{opt.range}</span>
                          </div>
                        </div>
                        <span className="font-black text-xs text-[#123B46]">{formatMoney(opt.price)}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-2 pl-6 leading-normal">{opt.description}</p>
                    </div>
                  );
                })}
              </div>

              {/* Vehicle & User Form */}
              <div className="space-y-2 pt-1 border-t border-slate-100">
                <span className="text-[11px] font-bold text-slate-700 block">2. Thông tin xe & liên hệ:</span>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-0.5">Biển số xe máy (ghi rõ đầy đủ):</label>
                  <input
                    type="text"
                    value={passPlate}
                    onChange={(e) => setPassPlate(e.target.value.toUpperCase())}
                    placeholder="VD: 59P2-9163"
                    className="w-full px-3 py-1.5 text-xs font-mono font-bold uppercase bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#20B7A6]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">Họ và tên:</label>
                    <input
                      type="text"
                      value={passFullName}
                      onChange={(e) => setPassFullName(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">Số điện thoại:</label>
                    <input
                      type="text"
                      value={passPhone}
                      onChange={(e) => setPassPhone(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Price summary */}
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 space-y-1 text-xs">
                <div className="flex justify-between text-slate-500 text-[11px]">
                  <span>Giá vé tháng:</span>
                  <span>{formatMoney(selectedSlot.price)}</span>
                </div>
                <div className="flex justify-between text-slate-500 text-[11px]">
                  <span>Phí tiện ích & bảo đảm chỗ:</span>
                  <span>{formatMoney(selectedSlot.fee)}</span>
                </div>
                <div className="flex justify-between font-extrabold text-[#123B46] text-xs pt-1 border-t border-slate-200">
                  <span>Tổng thanh toán:</span>
                  <span className="text-sm text-emerald-800">{formatMoney(selectedSlot.price + selectedSlot.fee)}</span>
                </div>
              </div>

              <button
                onClick={handleStartPassCheckout}
                className="w-full py-2.5 bg-[#123B46] hover:bg-[#1A4D5B] text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
              >
                Tiếp tục thanh toán VietQR
              </button>
            </div>
          </div>
        )}

        {/* ================= SCREEN: PAYMENT ================= */}
        {b2cScreen === 'payment' && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2cScreen('buy-pass')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Quay lại</span>
              </button>
              <span className="text-xs font-bold text-slate-700">Thanh toán VietQR</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-center space-y-3">
              <div>
                <span className="text-[11px] text-slate-500 block">Quét mã bằng ứng dụng Ngân hàng / ZaloPay</span>
                <span className="text-base font-black text-emerald-800 block mt-0.5">
                  {formatMoney(selectedSlot.price + selectedSlot.fee)}
                </span>
              </div>

              {/* Dynamic QR Display */}
              <div className="inline-block p-3 bg-white border-2 border-[#123B46] rounded-2xl shadow-sm mx-auto">
                <div className="grid grid-cols-21 gap-[2px] w-[147px] h-[147px]">
                  {generateQrMatrix(passPlate + selectedSlotId).map((row, r) =>
                    row.map((on, c) => (
                      <div
                        key={`${r}-${c}`}
                        className={`w-full h-full ${on ? 'bg-[#123B46]' : 'bg-white'}`}
                      />
                    ))
                  )}
                </div>
              </div>

              <div className="bg-slate-50 p-2 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-0.5 text-left">
                <p><strong>Ngân hàng:</strong> MB Bank (Quân Đội)</p>
                <p><strong>Số tài khoản:</strong> 9999.PARKEASY</p>
                <p><strong>Chủ tài khoản:</strong> CTY TNHH PARKEASY VIETNAM</p>
                <p><strong>Nội dung:</strong> VE THANG {passPlate}</p>
              </div>

              <p className="text-[10px] text-slate-400">
                Hệ thống tự động xác thực và kích hoạt vé trong vòng 3 giây sau khi nhận chuyển khoản.
              </p>

              <button
                disabled={isProcessingPayment}
                onClick={handleConfirmPayment}
                className="w-full py-2.5 bg-[#20B7A6] hover:bg-[#1AA393] text-[#123B46] text-xs font-extrabold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                {isProcessingPayment ? (
                  <>
                    <div className="w-4 h-4 border-2 border-[#123B46] border-t-transparent rounded-full animate-spin"></div>
                    <span>Đang kích hoạt vé tháng...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Mô phỏng thanh toán thành công</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* ================= SCREEN: MY PASSES ================= */}
        {b2cScreen === 'my-passes' && (
          <div className="p-3.5 space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setB2cScreen('home')}
                className="flex items-center gap-1 text-xs font-semibold text-[#123B46]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Trang chủ</span>
              </button>
              <span className="text-xs font-bold text-slate-700">Vé của tôi ({userMonthlyPasses.length})</span>
            </div>

            {userMonthlyPasses.map((pass) => (
              <div key={pass.id} className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="bg-[#123B46] text-white p-3 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[#D4F069] tracking-wider block">
                      Vé tháng ParkEasy
                    </span>
                    <h4 className="font-bold text-xs">{pass.lotName}</h4>
                  </div>
                  <span className="text-[10px] bg-[#20B7A6] text-[#123B46] px-2 py-0.5 rounded font-bold">
                    Đang hiệu lực
                  </span>
                </div>

                <div className="p-3.5 space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="space-y-1 text-xs">
                      <p><span className="text-slate-500 text-[11px]">Biển số:</span> <strong className="font-mono text-sm">{pass.plate}</strong></p>
                      <p><span className="text-slate-500 text-[11px]">Chủ xe:</span> <strong>{pass.fullName}</strong></p>
                      <p><span className="text-slate-500 text-[11px]">Khung giờ:</span> <strong>{pass.slotRange}</strong></p>
                      <p><span className="text-slate-500 text-[11px]">Hạn sử dụng:</span> <strong className="text-emerald-700">{pass.expiryDate}</strong></p>
                    </div>

                    <div className="p-2 border border-slate-200 rounded-xl bg-slate-50 shrink-0">
                      <div className="grid grid-cols-21 gap-[1.5px] w-[84px] h-[84px]">
                        {generateQrMatrix(pass.qrCode).map((row, r) =>
                          row.map((on, c) => (
                            <div
                              key={`${r}-${c}`}
                              className={`w-full h-full ${on ? 'bg-[#123B46]' : 'bg-white'}`}
                            />
                          ))
                        )}
                      </div>
                      <span className="text-[9px] font-mono text-center block mt-1 text-slate-500">Quét tại cổng</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Mã vé: {pass.qrCode}</span>
                    <button
                      onClick={() => addToast('Mở cổng bãi xe', `Mã vé ${pass.qrCode} đã sẵn sàng quét kiểm soát`, 'info')}
                      className="text-[#20B7A6] font-bold hover:underline"
                    >
                      Xuất trình bảo vệ
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. Bottom Navigation Bar for Zalo Mini App */}
      <div className="bg-white border-t border-slate-200 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] px-6 flex items-center justify-around text-xs shrink-0 z-20">
        <button
          onClick={() => {
            setB2cScreen('home');
            setActiveTab('lots');
          }}
          className={`flex flex-col items-center gap-0.5 ${
            b2cScreen === 'home' || b2cScreen === 'detail'
              ? 'text-[#123B46] font-bold'
              : 'text-slate-400 font-medium'
          }`}
        >
          <Search className="w-4 h-4" />
          <span>Tìm bãi</span>
        </button>

        <button
          onClick={() => {
            setB2cScreen('my-passes');
            setActiveTab('passes');
          }}
          className={`flex flex-col items-center gap-0.5 relative ${
            b2cScreen === 'my-passes' || b2cScreen === 'buy-pass' || b2cScreen === 'payment'
              ? 'text-[#123B46] font-bold'
              : 'text-slate-400 font-medium'
          }`}
        >
          <Ticket className="w-4 h-4" />
          <span>Vé của tôi</span>
          {userMonthlyPasses.length > 0 && (
            <span className="absolute -top-1 -right-2 w-4 h-4 bg-[#20B7A6] text-[#123B46] text-[9px] font-bold rounded-full flex items-center justify-center">
              {userMonthlyPasses.length}
            </span>
          )}
        </button>
      </div>
    </div>
  );
};
