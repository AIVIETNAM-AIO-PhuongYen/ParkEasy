import React from 'react';
import { useParkEasy } from '../context/ParkEasyContext';
import { B2CApp } from './B2CApp';
import { B2BApp } from './B2BApp';
import { 
  ArrowRightLeft, 
  Sparkles, 
  Activity, 
  Wifi, 
  WifiOff, 
  Plus, 
  Minus, 
  HelpCircle,
  Eye,
  CheckCircle2,
  Zap
} from 'lucide-react';

export const DualDeviceView: React.FC = () => {
  const {
    staffLot,
    recordVehicleIn,
    recordVehicleOut,
    toggleStaffOffline,
    isStaffOffline,
    pendingSyncCount,
    isLiveSimulating,
    toggleLiveSimulation,
    setViewMode,
    addToast
  } = useParkEasy();

  const handleQuickAddBike = () => {
    // Generate random 4 digits
    const plate = String(Math.floor(1000 + Math.random() * 9000));
    const types: ('Xe số' | 'Tay ga' | 'Xe điện')[] = ['Tay ga', 'Xe số', 'Xe điện'];
    const type = types[Math.floor(Math.random() * types.length)];
    recordVehicleIn(plate, type);
  };

  const handleQuickOutBike = () => {
    // Quick random plate from 4 digits
    const res = recordVehicleOut('4821', 'Tiền mặt');
    if (!res.success) {
      // Try another plate
      const randomPlate = String(Math.floor(1000 + Math.random() * 9000));
      recordVehicleOut(randomPlate, 'Tiền mặt');
    }
  };

  return (
    <div className="py-6 px-3 sm:px-6 max-w-7xl mx-auto space-y-6">
      
      {/* Top Interactive Sync Controller Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-sm flex flex-col lg:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#123B46] to-[#20B7A6] flex items-center justify-center text-white shadow-xs shrink-0">
            <ArrowRightLeft className="w-5 h-5 text-[#D4F069]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-extrabold text-sm text-[#123B46]">
                Demo Đồng Bộ Trực Tiếp (Real-Time Cloud Sync)
              </h2>
              <span className="text-[10px] bg-[#20B7A6]/15 text-[#123B46] font-bold px-2 py-0.5 rounded-full border border-[#20B7A6]/30">
                Firebase Data Flow
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Thao tác xe vào/ra trên máy nhân viên bãi (B2B) sẽ cập nhật số chỗ tức thời trên Zalo Mini App của khách (B2C)
            </p>
          </div>
        </div>

        {/* Quick Simulator Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleQuickAddBike}
            className="px-3 py-1.5 bg-[#20B7A6] hover:bg-[#1AA393] text-[#123B46] text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-2xs transition-all active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Thử xe vào (+1)</span>
          </button>

          <button
            onClick={handleQuickOutBike}
            className="px-3 py-1.5 bg-[#D4F069] hover:bg-[#C5E452] text-[#123B46] text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-2xs transition-all active:scale-95"
          >
            <Minus className="w-3.5 h-3.5" />
            <span>Thử xe ra (-1)</span>
          </button>

          <button
            onClick={toggleStaffOffline}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all ${
              isStaffOffline
                ? 'bg-amber-400 text-amber-950 shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {isStaffOffline ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5 text-slate-500" />}
            <span>{isStaffOffline ? `Offline (${pendingSyncCount})` : 'Mô phỏng mất mạng'}</span>
          </button>

          <button
            onClick={toggleLiveSimulation}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 border transition-all ${
              isLiveSimulating
                ? 'border-[#20B7A6] bg-[#20B7A6]/10 text-[#123B46]'
                : 'border-slate-200 bg-white text-slate-500'
            }`}
          >
            <Activity className={`w-3.5 h-3.5 ${isLiveSimulating ? 'text-[#20B7A6] animate-pulse' : ''}`} />
            <span>{isLiveSimulating ? 'Live Pulse: Bật' : 'Live Pulse: Tắt'}</span>
          </button>
        </div>
      </div>

      {/* Two Phones Side by Side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        
        {/* Device 1: B2C Zalo Mini App */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#123B46] text-white text-xs font-extrabold flex items-center justify-center">
                1
              </span>
              <div>
                <h3 className="font-bold text-sm text-[#123B46]">Mini App Người gửi xe (B2C)</h3>
                <p className="text-xs text-slate-500">Giao diện Zalo Mini App cho sinh viên, dân văn phòng</p>
              </div>
            </div>

            <button
              onClick={() => setViewMode('b2c')}
              className="text-xs text-[#20B7A6] font-semibold flex items-center gap-1 hover:underline"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Xem toàn màn hình</span>
            </button>
          </div>

          {/* Phone Frame */}
          <div className="relative mx-auto max-w-[390px] h-[780px] bg-slate-900 rounded-[44px] p-3 shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700/50">
            {/* Speaker & camera pill */}
            <div className="absolute top-4 inset-x-0 mx-auto w-28 h-4 bg-slate-950 rounded-full z-30"></div>
            
            {/* Screen inner container */}
            <div className="w-full h-full rounded-[34px] overflow-hidden bg-[#F4F6F5] relative">
              <B2CApp isEmbedded={true} />
            </div>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1 text-center">
            <p className="font-bold text-[#123B46]">🎯 Điểm cốt lõi B2C:</p>
            <p className="text-[11px] text-slate-500 leading-normal">
              Dùng ngay trong Zalo, 0đ rào cản tải app. Biết trước bãi còn chỗ và giá niêm yết trước khi xuất phát đến ga Metro.
            </p>
          </div>
        </div>

        {/* Device 2: B2B Staff SaaS App */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#20B7A6] text-[#123B46] text-xs font-extrabold flex items-center justify-center">
                2
              </span>
              <div>
                <h3 className="font-bold text-sm text-[#123B46]">Giao diện Nhân viên bãi (B2B SaaS)</h3>
                <p className="text-xs text-slate-500">Chạy trên smartphone nhân viên bảo vệ cổng bãi (0đ phần cứng)</p>
              </div>
            </div>

            <button
              onClick={() => setViewMode('b2b')}
              className="text-xs text-[#20B7A6] font-semibold flex items-center gap-1 hover:underline"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Xem toàn màn hình</span>
            </button>
          </div>

          {/* Phone Frame */}
          <div className="relative mx-auto max-w-[390px] h-[780px] bg-slate-900 rounded-[44px] p-3 shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700/50">
            {/* Speaker & camera pill */}
            <div className="absolute top-4 inset-x-0 mx-auto w-28 h-4 bg-slate-950 rounded-full z-30"></div>
            
            {/* Screen inner container */}
            <div className="w-full h-full rounded-[34px] overflow-hidden bg-[#F3F6F5] relative">
              <B2BApp isEmbedded={true} />
            </div>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1 text-center">
            <p className="font-bold text-[#123B46]">⚡ Điểm cốt lõi B2B:</p>
            <p className="text-[11px] text-slate-500 leading-normal">
              Thao tác dưới 3 chạm ("1-tap" +1 / -1), hoạt động mượt cả khi mất mạng (Offline Mode), chống thất thoát cho chủ bãi.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
