import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import {
  ParkingLot,
  ParkedVehicle,
  VehicleLog,
  VehicleType,
  UserMonthlyPass,
  AppViewMode
} from '../types/parkeasy';
import {
  INITIAL_PARKING_LOTS,
  INITIAL_PARKED_VEHICLES,
  INITIAL_RECENT_LOGS,
  MONTHLY_PASS_OPTIONS
} from '../data/initialData';

interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'warning' | 'info' | 'error';
}

interface ParkEasyContextType {
  // Mode & navigation
  viewMode: AppViewMode;
  setViewMode: (mode: AppViewMode) => void;
  selectedStationFilter: string;
  setSelectedStationFilter: (st: string) => void;

  // Data
  parkingLots: ParkingLot[];
  selectedLotId: number;
  setSelectedLotId: (id: number) => void;
  activeLot: ParkingLot;

  // Simulation
  isLiveSimulating: boolean;
  toggleLiveSimulation: () => void;
  triggerManualLotSync: () => void;

  // B2B Staff State
  staffActiveLotId: number;
  setStaffActiveLotId: (id: number) => void;
  staffLot: ParkingLot;
  isStaffOffline: boolean;
  toggleStaffOffline: () => void;
  pendingSyncCount: number;
  syncOfflineQueue: () => void;
  parkedVehicles: ParkedVehicle[];
  recentLogs: VehicleLog[];
  todayCashRevenue: number;
  todayDigitalRevenue: number;
  shiftClockMinute: number;

  // B2B Actions
  recordVehicleIn: (plateNumber: string, vehicleType: VehicleType, photoTaken?: boolean) => { success: boolean; error?: string; ticket?: ParkedVehicle };
  recordVehicleOut: (plateNumber: string, paymentMethod: 'Tiền mặt' | 'VietQR') => { success: boolean; error?: string; fee?: number; durationMinutes?: number; vehicle?: ParkedVehicle };
  performAuditCount: (physicalCount: number) => { discrepancy: number; discrepancyPercent: number; isWarning: boolean };

  // B2C Actions
  userMonthlyPasses: UserMonthlyPass[];
  purchaseMonthlyPass: (lotId: number, slotId: 'office' | 'full', plateNumber: string, fullName: string, phone: string) => UserMonthlyPass;
  submitLotCrowdReport: (lotId: number, isAccurate: boolean) => void;

  // Notification Toast
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'error') => void;
  removeToast: (id: string) => void;

  // AI Recommendation
  getAiRecommendation: (criteria: 'dist' | 'price' | 'free') => { primaryLot: ParkingLot; backupLot: ParkingLot; explanation: string };
}

const ParkEasyContext = createContext<ParkEasyContextType | null>(null);

export const ParkEasyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [viewMode, setViewMode] = useState<AppViewMode>('b2c');
  const [selectedStationFilter, setSelectedStationFilter] = useState<string>('all');
  const [parkingLots, setParkingLots] = useState<ParkingLot[]>(INITIAL_PARKING_LOTS);
  const [selectedLotId, setSelectedLotId] = useState<number>(1);
  const [staffActiveLotId, setStaffActiveLotId] = useState<number>(1);

  // B2B Staff State
  const [isStaffOffline, setIsStaffOffline] = useState<boolean>(false);
  const [pendingSyncCount, setPendingSyncCount] = useState<number>(0);
  const [parkedVehicles, setParkedVehicles] = useState<ParkedVehicle[]>(INITIAL_PARKED_VEHICLES);
  const [recentLogs, setRecentLogs] = useState<VehicleLog[]>(INITIAL_RECENT_LOGS);
  const [todayCashRevenue, setTodayCashRevenue] = useState<number>(420000); // 70 xe x 6.000đ
  const [todayDigitalRevenue, setTodayDigitalRevenue] = useState<number>(270000); // 45 xe x 6.000đ
  const [shiftClockMinute, setShiftClockMinute] = useState<number>(8 * 60 + 28); // 08:28

  // B2C State
  const [userMonthlyPasses, setUserMonthlyPasses] = useState<UserMonthlyPass[]>([
    {
      id: 'pass-01',
      lotId: 1,
      lotName: 'Bãi xe Ga ĐHQG – Cổng A',
      slotId: 'office',
      slotLabel: 'Giờ hành chính (8:00 – 18:00)',
      slotRange: '08:00 – 18:00',
      plate: '59P1-4821',
      fullName: 'Trương Phước Thành',
      phone: '0908 123 456',
      startDate: '01/10/2026',
      expiryDate: '31/10/2026',
      qrCode: 'PE-PASS-4821-OCT26',
      active: true,
      paidAmount: 195000
    }
  ]);

  // Simulation & Toasts
  const [isLiveSimulating, setIsLiveSimulating] = useState<boolean>(true);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const simTimerRef = useRef<NodeJS.Timeout | null>(null);

  const addToast = (title: string, message: string, type: 'success' | 'warning' | 'info' | 'error' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3800);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Active lot helpers
  const activeLot = parkingLots.find((l) => l.id === selectedLotId) || parkingLots[0];
  const staffLot = parkingLots.find((l) => l.id === staffActiveLotId) || parkingLots[0];

  // Helper format clock
  const getClockString = (min: number) => {
    const h = Math.floor(min / 60) % 24;
    const m = min % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  };

  // Toggle Live Simulation
  const toggleLiveSimulation = () => {
    setIsLiveSimulating((prev) => {
      const next = !prev;
      addToast(
        next ? 'Bật mô phỏng thời gian thực' : 'Tạm dừng mô phỏng',
        next ? 'Dữ liệu chỗ trống các ga sẽ tự động cập nhật mỗi 6 giây' : 'Đã giữ nguyên trạng thái dữ liệu',
        'info'
      );
      return next;
    });
  };

  // Simulate subtle real-time fluctuations
  useEffect(() => {
    if (!isLiveSimulating) {
      if (simTimerRef.current) clearInterval(simTimerRef.current);
      return;
    }

    simTimerRef.current = setInterval(() => {
      setShiftClockMinute((c) => c + 1);

      // Randomly tweak another lot (not the currently active staff lot unless needed)
      setParkingLots((prev) => {
        // Pick lot 2, 4, 5, 6, 7
        const lotCandidates = [2, 4, 5, 6, 7];
        const randomLotId = lotCandidates[Math.floor(Math.random() * lotCandidates.length)];

        return prev.map((lot) => {
          if (lot.id !== randomLotId) return lot;
          // Random delta between -1 and +1
          const delta = Math.random() > 0.5 ? 1 : -1;
          const newFree = Math.max(0, Math.min(lot.cap, lot.free + delta));
          return {
            ...lot,
            free: newFree,
            lastUpdatedMinutesAgo: 0
          };
        });
      });
    }, 6000);

    return () => {
      if (simTimerRef.current) clearInterval(simTimerRef.current);
    };
  }, [isLiveSimulating]);

  // Offline toggle for B2B staff
  const toggleStaffOffline = () => {
    setIsStaffOffline((prev) => {
      const next = !prev;
      if (next) {
        addToast(
          'Đang chạy Chế độ Ngoại tuyến (Offline)',
          'Mất mạng: Nhân viên vẫn ghi lượt xe bình thường trên bộ nhớ đệm smartphone. Hệ thống sẽ đồng bộ khi có kết nối.',
          'warning'
        );
      } else {
        if (pendingSyncCount > 0) {
          syncOfflineQueue();
        } else {
          addToast('Đã khôi phục kết nối mạng', 'Thiết bị đã kết nối trực tiếp với Firebase Cloud', 'success');
        }
      }
      return next;
    });
  };

  const syncOfflineQueue = () => {
    const count = pendingSyncCount;
    setPendingSyncCount(0);
    setIsStaffOffline(false);
    addToast(
      'Đồng bộ thành công!',
      `Đã tải lên ${count} lượt xe tạm lưu từ chế độ ngoại tuyến. Số chỗ trống trên Zalo Mini App đã đồng bộ tức thì.`,
      'success'
    );
  };

  const triggerManualLotSync = () => {
    setParkingLots((prev) =>
      prev.map((l) => ({ ...l, lastUpdatedMinutesAgo: 0 }))
    );
    addToast('Đã làm mới dữ liệu toàn hệ thống', 'Dữ liệu thời gian thực cập nhật từ các bãi xe quanh 14 ga Metro 1', 'success');
  };

  // Record Vehicle IN (+1)
  const recordVehicleIn = (plateNumber: string, vehicleType: VehicleType, photoTaken: boolean = false) => {
    const cleanPlate = plateNumber.trim();
    if (cleanPlate.length !== 4) {
      return { success: false, error: 'Vui lòng nhập đủ 4 số cuối của biển số xe (VD: 4821)' };
    }

    // Check if duplicate currently in staff lot
    if (parkedVehicles.some((v) => v.plate === cleanPlate)) {
      return { success: false, error: `Xe có biển số đuôi ${cleanPlate} đang có trong bãi. Vui lòng đối soát lại!` };
    }

    if (staffLot.free <= 0) {
      return { success: false, error: 'Bãi xe đã hết chỗ (0 chỗ trống). Vui lòng từ chối nhận xe!' };
    }

    const timeStr = getClockString(shiftClockMinute);
    const ticketCode = `PE-${cleanPlate}`;
    const newVehicle: ParkedVehicle = {
      id: `v-${Date.now()}`,
      plate: cleanPlate,
      type: vehicleType,
      inAt: timeStr,
      inTimestamp: Date.now(),
      ticketCode,
      photoUrl: photoTaken ? '/public/assets/aistudio/ParkEasy___Demo_UI_UX_2f3bfef8.html' : undefined
    };

    const newLog: VehicleLog = {
      id: `l-${Date.now()}`,
      kind: 'Vào',
      plate: cleanPlate,
      type: vehicleType,
      time: timeStr,
      timestamp: Date.now()
    };

    // Update staff parked & logs
    setParkedVehicles((prev) => [newVehicle, ...prev]);
    setRecentLogs((prev) => [newLog, ...prev.slice(0, 19)]);

    // Decrement free slot in lot
    setParkingLots((prev) =>
      prev.map((lot) => (lot.id === staffActiveLotId ? { ...lot, free: Math.max(0, lot.free - 1), lastUpdatedMinutesAgo: 0 } : lot))
    );

    if (isStaffOffline) {
      setPendingSyncCount((c) => c + 1);
      addToast(
        'Đã lưu xe vào (Ngoại tuyến)',
        `Biển số: ...${cleanPlate} (${vehicleType}). Lưu bộ nhớ đệm, chờ đồng bộ mạng.`,
        'warning'
      );
    } else {
      addToast(
        'Xe vào thành công! Đã đồng bộ Zalo Mini App',
        `Biển số: ...${cleanPlate} (${vehicleType}) vào lúc ${timeStr}. Chỗ trống bãi giảm còn ${staffLot.free - 1}.`,
        'success'
      );
    }

    return { success: true, ticket: newVehicle };
  };

  // Record Vehicle OUT (-1)
  const recordVehicleOut = (plateNumber: string, paymentMethod: 'Tiền mặt' | 'VietQR') => {
    const cleanPlate = plateNumber.trim();
    const vehicle = parkedVehicles.find((v) => v.plate === cleanPlate);

    if (!vehicle) {
      return { success: false, error: `Không tìm thấy xe có 4 số cuối ${cleanPlate} trong bãi.` };
    }

    const timeStr = getClockString(shiftClockMinute);
    const fee = staffLot.priceDay;

    // Remove from parked
    setParkedVehicles((prev) => prev.filter((v) => v.id !== vehicle.id));

    // Calculate duration in minutes (simulated ~45m if same timestamp)
    const durationMinutes = Math.max(15, Math.round((Date.now() - vehicle.inTimestamp) / (60 * 1000)));

    const newLog: VehicleLog = {
      id: `l-${Date.now()}`,
      kind: 'Ra',
      plate: vehicle.plate,
      type: vehicle.type,
      time: timeStr,
      timestamp: Date.now(),
      fee,
      method: paymentMethod
    };

    setRecentLogs((prev) => [newLog, ...prev.slice(0, 19)]);

    // Increment free slot
    setParkingLots((prev) =>
      prev.map((lot) => (lot.id === staffActiveLotId ? { ...lot, free: Math.min(lot.cap, lot.free + 1), lastUpdatedMinutesAgo: 0 } : lot))
    );

    // Track revenue
    if (paymentMethod === 'Tiền mặt') {
      setTodayCashRevenue((r) => r + fee);
    } else {
      setTodayDigitalRevenue((r) => r + fee);
    }

    if (isStaffOffline) {
      setPendingSyncCount((c) => c + 1);
      addToast(
        'Đã lưu xe ra (Ngoại tuyến)',
        `Đã thu ${fee.toLocaleString()}đ (${paymentMethod}). Lưu bộ nhớ đệm, chờ đồng bộ mạng.`,
        'warning'
      );
    } else {
      addToast(
        'Xe ra thành công! Đã đồng bộ Zalo Mini App',
        `Xe ...${vehicle.plate} xuất bãi lúc ${timeStr}. Thu phí ${fee.toLocaleString()}đ. Chỗ trống tăng lên ${staffLot.free + 1}.`,
        'success'
      );
    }

    return { success: true, fee, durationMinutes, vehicle };
  };

  // Perform audit count
  const performAuditCount = (physicalCount: number) => {
    const systemCount = staffLot.cap - staffLot.free;
    const discrepancy = Math.abs(physicalCount - systemCount);
    const discrepancyPercent = (discrepancy / Math.max(1, systemCount)) * 100;
    const isWarning = discrepancyPercent > 5;

    if (isWarning) {
      addToast(
        'Cảnh báo chênh lệch đối soát > 5%!',
        `Thực tế: ${physicalCount} xe, Hệ thống ghi nhận: ${systemCount} xe (Lệch ${discrepancy} xe - ${discrepancyPercent.toFixed(1)}%). Đã gửi cảnh báo đến chủ bãi.`,
        'warning'
      );
    } else {
      addToast(
        'Đối soát ca trực hợp lệ!',
        `Số xe thực tế (${physicalCount}) khớp sát với hệ thống (${systemCount}). Tỷ lệ sai số an toàn: ${discrepancyPercent.toFixed(1)}%.`,
        'success'
      );
    }

    return { discrepancy, discrepancyPercent, isWarning };
  };

  // B2C: Purchase Monthly Pass
  const purchaseMonthlyPass = (
    lotId: number,
    slotId: 'office' | 'full',
    plateNumber: string,
    fullName: string,
    phone: string
  ): UserMonthlyPass => {
    const lot = parkingLots.find((l) => l.id === lotId) || parkingLots[0];
    const opt = MONTHLY_PASS_OPTIONS.find((o) => o.id === slotId) || MONTHLY_PASS_OPTIONS[0];
    const totalAmount = opt.price + opt.fee;

    const newPass: UserMonthlyPass = {
      id: `pass-${Date.now()}`,
      lotId: lot.id,
      lotName: lot.name,
      slotId,
      slotLabel: opt.label,
      slotRange: opt.range,
      plate: plateNumber.toUpperCase(),
      fullName,
      phone,
      startDate: '01/11/2026',
      expiryDate: '30/11/2026',
      qrCode: `PE-PASS-${plateNumber.replace(/[^A-Za-z0-9]/g, '')}-NOV26`,
      active: true,
      paidAmount: totalAmount
    };

    setUserMonthlyPasses((prev) => [newPass, ...prev]);

    // Also record digital revenue
    setTodayDigitalRevenue((r) => r + totalAmount);

    addToast(
      'Kích hoạt vé tháng thành công!',
      `Đã kích hoạt vé tháng cố định ${opt.label} tại ${lot.name}. Mã vé: ${newPass.qrCode}.`,
      'success'
    );

    return newPass;
  };

  // B2C: Submit crowd validation report
  const submitLotCrowdReport = (lotId: number, isAccurate: boolean) => {
    const lot = parkingLots.find((l) => l.id === lotId);
    if (!lot) return;

    if (isAccurate) {
      addToast(
        'Cảm ơn đóng góp của bạn!',
        `Bạn đã xác nhận thông tin ${lot.free} chỗ trống tại ${lot.name} là chính xác.`,
        'success'
      );
    } else {
      addToast(
        'Đã ghi nhận báo cáo sai lệch',
        `Nhóm vận hành ParkEasy sẽ liên hệ điều phối viên bãi ${lot.name} để kiểm tra lại thực tế ngay lập tức.`,
        'info'
      );
    }
  };

  // AI Recommendation engine
  const getAiRecommendation = (criteria: 'dist' | 'price' | 'free') => {
    const sorted = [...parkingLots];
    if (criteria === 'dist') {
      sorted.sort((a, b) => a.dist - b.dist);
    } else if (criteria === 'price') {
      sorted.sort((a, b) => a.priceDay - b.priceDay || a.dist - b.dist);
    } else {
      sorted.sort((a, b) => b.free - a.free || a.dist - b.dist);
    }

    // Ensure primary has available slots
    const primaryLot = sorted.find((l) => l.free > 5) || sorted[0];
    const backupLot = sorted.find((l) => l.id !== primaryLot.id && l.free > 0) || sorted[1] || sorted[0];

    let explanation = '';
    if (criteria === 'dist') {
      explanation = `Được chọn vì cách điểm đến chỉ ${primaryLot.dist}m, còn ${primaryLot.free} chỗ trống với mức giá ${primaryLot.priceDay.toLocaleString()}đ/lượt.`;
    } else if (criteria === 'price') {
      explanation = `Được chọn vì giá tốt nhất (${primaryLot.priceDay.toLocaleString()}đ/lượt), cự ly đi bộ ${primaryLot.dist}m, thích hợp gửi dài ngày.`;
    } else {
      explanation = `Được chọn vì có tỷ lệ chỗ trống dồi dào nhất (${primaryLot.free}/${primaryLot.cap} chỗ trống), an tâm không sợ hết chỗ giờ cao điểm.`;
    }

    return { primaryLot, backupLot, explanation };
  };

  return (
    <ParkEasyContext.Provider
      value={{
        viewMode,
        setViewMode,
        selectedStationFilter,
        setSelectedStationFilter,
        parkingLots,
        selectedLotId,
        setSelectedLotId,
        activeLot,
        isLiveSimulating,
        toggleLiveSimulation,
        triggerManualLotSync,
        staffActiveLotId,
        setStaffActiveLotId,
        staffLot,
        isStaffOffline,
        toggleStaffOffline,
        pendingSyncCount,
        syncOfflineQueue,
        parkedVehicles,
        recentLogs,
        todayCashRevenue,
        todayDigitalRevenue,
        shiftClockMinute,
        recordVehicleIn,
        recordVehicleOut,
        performAuditCount,
        userMonthlyPasses,
        purchaseMonthlyPass,
        submitLotCrowdReport,
        toasts,
        addToast,
        removeToast,
        getAiRecommendation
      }}
    >
      {children}
    </ParkEasyContext.Provider>
  );
};

export const useParkEasy = () => {
  const ctx = useContext(ParkEasyContext);
  if (!ctx) throw new Error('useParkEasy must be used within ParkEasyProvider');
  return ctx;
};
