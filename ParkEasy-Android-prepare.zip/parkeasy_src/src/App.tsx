import React from 'react';
import { ParkEasyProvider, useParkEasy } from './context/ParkEasyContext';
import { Header } from './components/Header';
import { DualDeviceView } from './components/DualDeviceView';
import { B2CApp } from './components/B2CApp';
import { B2BApp } from './components/B2BApp';
import { MetroMapView } from './components/MetroMapView';
import { ProjectBusinessPlan } from './components/ProjectBusinessPlan';
import { ToastContainer } from './components/ToastContainer';

const MainLayout: React.FC = () => {
  const { viewMode } = useParkEasy();

  return (
    <div className={`flex flex-col bg-[#F4F6F5] text-[#123B46] ${viewMode === 'b2c' || viewMode === 'b2b' ? 'h-[100dvh] overflow-hidden' : 'min-h-screen'}`}>
      {(viewMode === 'map' || viewMode === 'project-info' || viewMode === 'dual') && <Header />}

      <main className={viewMode === 'b2c' || viewMode === 'b2b' ? 'flex-1 min-h-0' : 'flex-1'}>
        {viewMode === 'dual' && <DualDeviceView />}
        {viewMode === 'b2c' && (
          <B2CApp isEmbedded={false} />
        )}
        {viewMode === 'b2b' && (
          <B2BApp isEmbedded={false} />
        )}
        {viewMode === 'map' && <MetroMapView />}
        {viewMode === 'project-info' && <ProjectBusinessPlan />}
      </main>

      {/* Quiet, elegant footer with project context */}
      {viewMode !== 'b2c' && viewMode !== 'b2b' && <footer className="bg-white border-t border-slate-200 py-6 px-4 sm:px-8 text-xs text-slate-500 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-md bg-[#123B46] text-[#D4F069] flex items-center justify-center font-bold text-[10px]">
              PE
            </div>
            <span className="font-bold text-[#123B46]">Dự án ParkEasy</span>
            <span>·</span>
            <span>Trường Đại học Kinh tế – Luật (ĐHQG TP.HCM)</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-500">
            <span>Zalo Mini App B2C</span>
            <span>·</span>
            <span>SaaS B2B 0đ Phần Cứng</span>
            <span>·</span>
            <span>Real-time Sync</span>
          </div>
        </div>
      </footer>}

      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <ParkEasyProvider>
      <MainLayout />
    </ParkEasyProvider>
  );
}
