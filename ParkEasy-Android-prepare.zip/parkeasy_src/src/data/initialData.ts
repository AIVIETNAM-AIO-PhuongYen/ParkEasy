import { ParkingLot, ParkedVehicle, VehicleLog, MonthlyPassOption } from '../types/parkeasy';

export const METRO_STATIONS = [
  { id: 'st1', name: 'Ga Bến Thành', line: 'Metro 1', distKm: 0, district: 'Quận 1' },
  { id: 'st2', name: 'Ga Nhà hát Thành phố', line: 'Metro 1', distKm: 0.6, district: 'Quận 1' },
  { id: 'st3', name: 'Ga Ba Son', line: 'Metro 1', distKm: 1.7, district: 'Quận 1' },
  { id: 'st4', name: 'Ga Văn Thánh', line: 'Metro 1', distKm: 3.2, district: 'Bình Thạnh' },
  { id: 'st5', name: 'Ga Tân Cảng', line: 'Metro 1', distKm: 4.5, district: 'Bình Thạnh' },
  { id: 'st6', name: 'Ga Thảo Điền', line: 'Metro 1', distKm: 6.3, district: 'TP. Thủ Đức' },
  { id: 'st7', name: 'Ga An Phú', line: 'Metro 1', distKm: 7.8, district: 'TP. Thủ Đức' },
  { id: 'st8', name: 'Ga Rạch Chiếc', line: 'Metro 1', distKm: 9.6, district: 'TP. Thủ Đức' },
  { id: 'st9', name: 'Ga Phước Long', line: 'Metro 1', distKm: 11.2, district: 'TP. Thủ Đức' },
  { id: 'st10', name: 'Ga Bình Thái', line: 'Metro 1', distKm: 13.0, district: 'TP. Thủ Đức' },
  { id: 'st11', name: 'Ga Thủ Đức', line: 'Metro 1', distKm: 15.1, district: 'TP. Thủ Đức' },
  { id: 'st12', name: 'Ga Khu Công nghệ cao', line: 'Metro 1', distKm: 17.2, district: 'TP. Thủ Đức' },
  { id: 'st13', name: 'Ga Đại học Quốc gia', line: 'Metro 1', distKm: 18.8, district: 'TP. Thủ Đức' },
  { id: 'st14', name: 'Ga Bến xe Suối Tiên', line: 'Metro 1', distKm: 19.7, district: 'TP. Thủ Đức' }
];

export const INITIAL_PARKING_LOTS: ParkingLot[] = [
  {
    id: 1,
    name: 'Bãi xe Ga ĐHQG – Cổng A',
    area: 'Ga Đại học Quốc gia',
    station: 'Ga Đại học Quốc gia',
    address: 'Số 1 Đường Song Hành Xa Lộ Hà Nội, P. Linh Trung, TP. Thủ Đức',
    cap: 80,
    free: 28,
    dist: 120,
    priceDay: 6000,
    priceNight: 9000,
    hours: '05:00 – 22:00',
    night: 'Không nhận',
    hasCover: true,
    hasCamera: true,
    hasPCCC: true,
    isPartner: true,
    coordinates: { lat: 10.8715, lng: 106.8028 },
    lastUpdatedMinutesAgo: 1,
    rateScore: 4.8,
    reviewCount: 142
  },
  {
    id: 2,
    name: 'Bãi xe Suối Tiên 1',
    area: 'Ga Suối Tiên',
    station: 'Ga Bến xe Suối Tiên',
    address: 'Gần lối vào Bến xe Miền Đông Mới, P. Long Bình, TP. Thủ Đức',
    cap: 100,
    free: 9, // Sắp đầy (<15%)
    dist: 260,
    priceDay: 6000,
    priceNight: 9000,
    hours: '05:00 – 23:00',
    night: 'Có nhận',
    hasCover: true,
    hasCamera: true,
    hasPCCC: true,
    isPartner: true,
    coordinates: { lat: 10.8802, lng: 106.8124 },
    lastUpdatedMinutesAgo: 2,
    rateScore: 4.6,
    reviewCount: 98
  },
  {
    id: 3,
    name: 'Bãi xe Ký túc xá Khu B ĐHQG',
    area: 'Khu Ký túc xá ĐHQG',
    station: 'Ga Đại học Quốc gia',
    address: 'Đường Tô Vĩnh Diện, Khu Đô thị ĐHQG, TP. Thủ Đức',
    cap: 60,
    free: 0, // Hết chỗ
    dist: 340,
    priceDay: 5000,
    priceNight: 8000,
    hours: '05:30 – 22:00',
    night: 'Không nhận',
    hasCover: false,
    hasCamera: true,
    hasPCCC: true,
    isPartner: true,
    coordinates: { lat: 10.8791, lng: 106.7975 },
    lastUpdatedMinutesAgo: 4,
    rateScore: 4.2,
    reviewCount: 85
  },
  {
    id: 4,
    name: 'Bãi xe Đối diện Ga Thủ Đức',
    area: 'Ga Thủ Đức',
    station: 'Ga Thủ Đức',
    address: '128 Đường Võ Văn Ngân, P. Trường Thọ, TP. Thủ Đức',
    cap: 80,
    free: 40,
    dist: 480,
    priceDay: 6000,
    priceNight: 9000,
    hours: '05:00 – 22:30',
    night: 'Không nhận',
    hasCover: true,
    hasCamera: true,
    hasPCCC: true,
    isPartner: true,
    coordinates: { lat: 10.8524, lng: 106.7645 },
    lastUpdatedMinutesAgo: 1,
    rateScore: 4.7,
    reviewCount: 110
  },
  {
    id: 5,
    name: 'Bãi xe Khu Công nghệ cao',
    area: 'Gần Khu CNC',
    station: 'Ga Khu Công nghệ cao',
    address: 'Đường D1, Khu Công nghệ cao TP.HCM, TP. Thủ Đức',
    cap: 120,
    free: 75,
    dist: 700,
    priceDay: 7000,
    priceNight: 10000,
    hours: '06:00 – 21:00',
    night: 'Không nhận',
    hasCover: true,
    hasCamera: true,
    hasPCCC: true,
    isPartner: true,
    coordinates: { lat: 10.8582, lng: 106.7865 },
    lastUpdatedMinutesAgo: 3,
    rateScore: 4.5,
    reviewCount: 64
  },
  {
    id: 6,
    name: 'Bãi xe Ga Văn Thánh',
    area: 'Ga Văn Thánh',
    station: 'Ga Văn Thánh',
    address: '48/10 Điện Biên Phủ, Phường 22, Q. Bình Thạnh',
    cap: 90,
    free: 35,
    dist: 180,
    priceDay: 6000,
    priceNight: 9000,
    hours: '05:00 – 23:00',
    night: 'Có nhận',
    hasCover: true,
    hasCamera: true,
    hasPCCC: true,
    isPartner: true,
    coordinates: { lat: 10.7985, lng: 106.7188 },
    lastUpdatedMinutesAgo: 2,
    rateScore: 4.9,
    reviewCount: 176
  },
  {
    id: 7,
    name: 'Bãi xe Ngầm Ga Bến Thành',
    area: 'Ga Bến Thành',
    station: 'Ga Bến Thành',
    address: 'Quảng trường Quách Thị Trang, Phường Bến Thành, Quận 1',
    cap: 150,
    free: 52,
    dist: 90,
    priceDay: 6000,
    priceNight: 9000,
    hours: '24/24',
    night: 'Có nhận',
    hasCover: true,
    hasCamera: true,
    hasPCCC: true,
    isPartner: true,
    coordinates: { lat: 10.7721, lng: 106.6983 },
    lastUpdatedMinutesAgo: 1,
    rateScore: 4.9,
    reviewCount: 320
  }
];

export const INITIAL_PARKED_VEHICLES: ParkedVehicle[] = [
  { id: 'v1', plate: '4821', type: 'Tay ga', inAt: '07:42', inTimestamp: Date.now() - 48 * 60 * 1000, ticketCode: 'PE-4821' },
  { id: 'v2', plate: '0735', type: 'Xe số', inAt: '07:55', inTimestamp: Date.now() - 35 * 60 * 1000, ticketCode: 'PE-0735' },
  { id: 'v3', plate: '9163', type: 'Xe điện', inAt: '08:10', inTimestamp: Date.now() - 20 * 60 * 1000, ticketCode: 'PE-9163' },
  { id: 'v4', plate: '2489', type: 'Tay ga', inAt: '08:18', inTimestamp: Date.now() - 12 * 60 * 1000, ticketCode: 'PE-2489' },
  { id: 'v5', plate: '6610', type: 'Xe số', inAt: '08:24', inTimestamp: Date.now() - 6 * 60 * 1000, ticketCode: 'PE-6610' }
];

export const INITIAL_RECENT_LOGS: VehicleLog[] = [
  { id: 'l1', kind: 'Vào', plate: '6610', type: 'Xe số', time: '08:24', timestamp: Date.now() - 6 * 60 * 1000 },
  { id: 'l2', kind: 'Vào', plate: '2489', type: 'Tay ga', time: '08:18', timestamp: Date.now() - 12 * 60 * 1000 },
  { id: 'l3', kind: 'Ra', plate: '5520', type: 'Xe số', time: '08:15', timestamp: Date.now() - 15 * 60 * 1000, fee: 6000, method: 'Tiền mặt' },
  { id: 'l4', kind: 'Vào', plate: '9163', type: 'Xe điện', time: '08:10', timestamp: Date.now() - 20 * 60 * 1000 },
  { id: 'l5', kind: 'Ra', plate: '3318', type: 'Tay ga', time: '08:02', timestamp: Date.now() - 28 * 60 * 1000, fee: 6000, method: 'VietQR' },
  { id: 'l6', kind: 'Vào', plate: '0735', type: 'Xe số', time: '07:55', timestamp: Date.now() - 35 * 60 * 1000 }
];

export const MONTHLY_PASS_OPTIONS: MonthlyPassOption[] = [
  {
    id: 'office',
    label: 'Giờ hành chính',
    range: '8:00 – 18:00 (Thứ 2 – Thứ 7)',
    price: 180000,
    fee: 15000,
    description: 'Phù hợp sinh viên và nhân viên văn phòng đi làm. Sau 18h bãi có thể tiếp nhận khách vãng lai.'
  },
  {
    id: 'full',
    label: 'Cả ngày',
    range: '06:00 – 22:00 (Tất cả các ngày)',
    price: 240000,
    fee: 15000,
    description: 'Giữ chỗ đỗ linh hoạt cả ngày, thoải mái gửi xe học thêm, làm ca đêm hoặc đi chơi cuối tuần.'
  }
];

export const PROJECT_TEAM_MEMBERS = [
  {
    name: 'Trương Phước Thành',
    role: 'Trưởng nhóm Dự án',
    focus: 'Quản trị chung và định hướng chiến lược',
    duties: 'Định hình tầm nhìn, sứ mệnh, lộ trình phát triển 1–3 năm. Điều phối các bộ phận chức năng, đàm phán hợp tác đối tác & ban cố vấn.',
    equity: '20% (4.000.000 đ)',
    avatar: 'TPT'
  },
  {
    name: 'Nguyễn Phan Yến Phương',
    role: 'Phụ trách Kỹ thuật & Sản phẩm',
    focus: 'Xây dựng phát triển app & vận hành kỹ thuật',
    duties: 'Phát triển Zalo Mini App B2C và nền tảng SaaS B2B cho nhân viên bãi. Thiết lập cơ chế đồng bộ real-time, chế độ ngoại tuyến.',
    equity: '20% (4.000.000 đ)',
    avatar: 'NPYP'
  },
  {
    name: 'Trần Xuân Linh',
    role: 'Phụ trách Phát triển đối tác bãi xe',
    focus: 'Phát triển thị trường & quan hệ đối tác B2B',
    duties: 'Khảo sát thực địa bãi xe tư nhân quanh ga Metro số 1 & trường đại học. Đào tạo nhân viên giữ xe thao tác dưới 3 chạm.',
    equity: '20% (4.000.000 đ)',
    avatar: 'TXL'
  },
  {
    name: 'Lưu Gia Thịnh',
    role: 'Phụ trách Marketing & Truyền thông',
    focus: 'Phát triển người dùng & truyền thông thương hiệu',
    duties: 'Thiết kế ấn phẩm nhận diện tại bãi (mã QR, standee), truyền thông Zalo OA, kênh sinh viên và đo lường độ chính xác dữ liệu.',
    equity: '20% (4.000.000 đ)',
    avatar: 'LGT'
  },
  {
    name: 'Diệp Như Ý',
    role: 'Phụ trách Tài chính & Pháp lý',
    focus: 'Quản trị tài chính & pháp chế doanh nghiệp',
    duties: 'Dự toán thu chi, kiểm soát chi phí hạ tầng máy chủ, xây dựng cơ chế hạch toán doanh thu và tuân thủ Luật Bảo vệ dữ liệu cá nhân.',
    equity: '20% (4.000.000 đ)',
    avatar: 'DNY'
  }
];

export const ADVISOR_INFO = {
  name: 'TS. Phạm Trung Tuấn',
  title: 'Giảng viên Khoa Quản trị Kinh doanh',
  institution: 'Trường Đại học Kinh tế – Luật (ĐHQG TP.HCM)',
  role: 'Cố vấn chuyên môn dự án',
  description: 'Thẩm định tính khả thi của lộ trình phát triển sản phẩm, định hướng quyết sách cốt lõi về thị trường và mô hình kinh doanh khởi nghiệp.'
};
