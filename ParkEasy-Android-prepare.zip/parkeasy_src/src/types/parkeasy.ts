export type VehicleType = 'Xe số' | 'Tay ga' | 'Xe điện';

export type ParkingSlotStatus = 'Còn chỗ' | 'Sắp đầy' | 'Hết chỗ';

export interface ParkingLot {
  id: number;
  name: string;
  area: string;
  station: string;
  address: string;
  cap: number;
  free: number;
  dist: number; // in meters
  priceDay: number; // VND per turn
  priceNight: number; // VND per turn
  hours: string;
  night: string; // 'Có nhận' | 'Không nhận'
  hasCover: boolean; // có mái che
  hasCamera: boolean;
  hasPCCC: boolean;
  isPartner: boolean; // Bãi đối tác ParkEasy chính thức
  coordinates: { lat: number; lng: number };
  lastUpdatedMinutesAgo: number;
  rateScore: number;
  reviewCount: number;
}

export interface ParkedVehicle {
  id: string;
  plate: string;
  type: VehicleType;
  inAt: string; // '07:45'
  inTimestamp: number;
  photoUrl?: string;
  isMonthlyPass?: boolean;
  ticketCode: string;
}

export interface VehicleLog {
  id: string;
  kind: 'Vào' | 'Ra';
  plate: string;
  type: VehicleType;
  time: string;
  timestamp: number;
  fee?: number;
  method?: 'Tiền mặt' | 'VietQR' | 'Vé tháng';
}

export interface MonthlyPassOption {
  id: 'office' | 'full';
  label: string;
  range: string;
  price: number;
  fee: number;
  description: string;
}

export interface UserMonthlyPass {
  id: string;
  lotId: number;
  lotName: string;
  slotId: 'office' | 'full';
  slotLabel: string;
  slotRange: string;
  plate: string;
  fullName: string;
  phone: string;
  startDate: string;
  expiryDate: string;
  qrCode: string;
  active: boolean;
  paidAmount: number;
}

export type AppViewMode = 'dual' | 'b2c' | 'b2b' | 'map' | 'project-info';
