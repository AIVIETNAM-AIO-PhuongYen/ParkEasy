# ParkEasy – Ứng Dụng Tìm Kiếm & Quản Lý Bãi Đỗ Xe Máy Thông Minh

Ứng dụng di động độc lập (Mobile App Experience) cho dự án ParkEasy, cho phép người dùng trực tiếp sử dụng đầy đủ các tính năng gửi xe máy (B2C) và thao tác vận hành bãi đỗ (B2B) trên một giao diện smartphone chuẩn mực, trực quan và đồng bộ thời gian thực.

## User Review & Critical Decisions

> [!IMPORTANT]
> Dựa trên phản hồi khảo sát của bạn, cấu trúc và định hướng của ứng dụng ParkEasy được thiết lập như sau:

- **Giao diện mặc định**: Mở trực tiếp vào **App Người gửi xe (B2C)** như một ứng dụng người dùng thực thụ, có nút chuyển đổi vai trò linh hoạt ở góc màn hình để chuyển sang **Chế độ Nhân viên bãi (B2B SaaS)** và ngược lại.
- **Bố cục hiển thị**: Giao diện chuẩn tỷ lệ smartphone di động (Mobile App UI) với khung viền hiện đại, tối ưu công thái học ngón tay cái (Thumb-zone), thanh điều hướng đáy (Bottom Navigation Tab Bar) và thao tác mượt mà.
- **Dữ liệu & Thời gian thực**: Cơ chế đồng bộ trạng thái chỗ trống (Real-time Occupancy) hai chiều tức thời giữa lượt xe vào/ra của nhân viên và danh sách tìm kiếm của khách hàng, tích hợp lưu trữ ngoại tuyến (Offline Mode) và sao lưu Firebase Cloud Firestore khi có kết nối.

---

## 1. Overview & Core Concept

- **Mục tiêu sản phẩm**: Cung cấp một ứng dụng thực thụ giúp người đi xe máy tại TP.HCM (đặc biệt dọc tuyến Metro số 1 Bến Thành – Suối Tiên và các cụm trường đại học) biết chính xác bãi đỗ nào còn chỗ trống, giá niêm yết theo Quyết định 35/2018/QĐ-UBND, chỉ đường Google Maps và đăng ký vé tháng giữ chỗ. Đồng thời, cung cấp giao diện thao tác nhanh dưới 3 chạm ("1-tap" +1 / -1) cho nhân viên bảo vệ cổng bãi mà không cần đầu tư thiết bị phần cứng đắt tiền.
- **Đối tượng sử dụng**:
  - *Người gửi xe (B2C)*: Sinh viên, nhân viên văn phòng đi metro/đi làm hàng ngày.
  - *Nhân viên & Chủ bãi xe (B2B)*: Người trực tiếp soát vé tại cổng và quản lý doanh thu bãi đỗ.

---

## 2. User Experience & Visual Design

### Key User Flows

```
[B2C - Người gửi xe]
Trang chủ tìm bãi ──> Chọn ga/Lọc bãi ──> Xem chi tiết bãi & Chỉ đường ──> Đăng ký vé tháng VietQR ──> Vé điện tử của tôi
       │
       ▼ (Chuyển chế độ nhanh)
[B2B - Nhân viên bãi]
Trực cổng bãi ──> Xe vào (+1: nhập 4 số) ──> Sinh vé QR ──> Xe ra (-1: quét/thu tiền) ──> Đối soát & Báo cáo doanh thu
```

- **Flow 1: Tìm bãi đỗ xe thời gian thực (B2C)**:
  - Thanh tìm kiếm theo tên bãi, khu vực, trường học hoặc ga Metro 1.
  - Phân loại trực quan mức độ trống bằng màu chuẩn: **Còn chỗ** (Xanh `#DDF3E6`), **Sắp đầy** (Vàng `#FFF0C2`), **Hết chỗ** (Đỏ `#FBDADA`).
  - Gợi ý thông minh từ Trợ lý ParkEasy: Phân tích bãi đỗ tối ưu nhất theo 3 tiêu chí chọn nhanh (Gần nhất, Rẻ nhất, Nhiều chỗ nhất).
- **Flow 2: Chỉ đường & Mua vé tháng (B2C)**:
  - Nút "Chỉ đường" kết nối trực tiếp đến vị trí cổng bãi xe qua Google Maps.
  - Mua vé tháng khung giờ (Giờ hành chính 180.000đ vs Cả ngày 240.000đ), quét mã VietQR tự động kích hoạt vé điện tử có mã QR để quét tại cổng.
- **Flow 3: Thao tác vào bãi "1-Tap" (B2B)**:
  - Chọn loại xe (`Xe số`, `Tay ga`, `Xe điện`), bàn phím số lớn nhập nhanh 4 số cuối biển số xe.
  - Tự động trừ 1 chỗ trống, sinh mã QR lượt xe cho khách chụp/lưu.
- **Flow 4: Thao tác xuất bãi & Thu phí (B2B)**:
  - Quét mã QR hoặc nhập 4 số cuối -> Hệ thống hiển thị thời gian đỗ và số tiền cần thu -> Thu tiền mặt hoặc quét VietQR -> Cộng lại 1 chỗ trống tức thì.
- **Flow 5: Chế độ Ngoại tuyến & Đối soát ca trực (B2B)**:
  - Công tắc Offline Mode: Lưu lượt xe vào bộ nhớ đệm khi mất mạng, tự động đồng bộ khi có kết nối.
  - Chức năng đối soát ca trực kiểm tra sai số đếm thực tế (ngưỡng cảnh báo > 5%).

### Visual Identity & Palette

- **Màu chủ đạo (Teal)**: `#123B46` (Uy tín, chuyên nghiệp, vững chắc).
- **Màu bổ trợ (Mint)**: `#20B7A6` (Linh hoạt, tươi sáng, nút xe vào).
- **Màu nhấn (Lime)**: `#D4F069` (Thu hút thị giác, nút xe ra, nổi bật).
- **Typography**: `Be Vietnam Pro` cho tiêu đề và nội dung; `JetBrains Mono` / `tabular-nums` cho số chỗ, biển số và mã QR.

---

## 3. Key Product Decisions & Trade-Offs

- **Thiết kế Mobile-First Standalone**: Thay vì hiển thị dạng slide thuyết trình, ứng dụng được dựng thành một app di động hoàn chỉnh có thể dùng trực tiếp trên mọi kích thước màn hình, có khung điện thoại giả lập tinh tế trên desktop và mở rộng tự nhiên trên thiết bị di động.
- **Chuyển đổi vai trò linh hoạt (Role Switcher Floating Dock)**: Nút chuyển chế độ nổi (Floating Switcher) cho phép người dùng chuyển tức thì giữa giao diện Khách gửi xe (B2C) và Nhân viên bãi (B2B) để kiểm tra luồng nghiệp vụ thực tế.
- **Đồng bộ trạng thái hai chiều**: Dữ liệu lượt xe ra vào tác động trực tiếp vào cơ sở dữ liệu dùng chung, đảm bảo khi nhân viên thao tác thì Mini App B2C cập nhật ngay mà không cần tải lại trang.

---

## 4. Technical Architecture & Data Strategy

```
┌───────────────────────────────────────────────────────────────┐
│                     ParkEasy Mobile App                       │
├───────────────────────────────┬───────────────────────────────┤
│    B2C Mode (Khách gửi xe)    │   B2B Mode (Nhân viên bãi)    │
│  - Danh sách bãi real-time    │  - Thao tác vào bãi (+1)      │
│  - Chi tiết bãi & Chỉ đường   │  - Thao tác ra bãi (-1)       │
│  - Trợ lý gợi ý bãi AI        │  - Chế độ Ngoại tuyến         │
│  - Mua vé tháng & VietQR      │  - Đối soát lệch > 5%         │
│  - Quản lý vé QR cá nhân      │  - Báo cáo ca trực & doanh thu│
└───────────────┬───────────────┴───────────────┬───────────────┘
                │                               │
                ▼                               ▼
┌───────────────────────────────────────────────────────────────┐
│              ParkEasy Sync & Storage Engine                   │
│   - Quản lý bãi đỗ xe (Parking Lots State)                    │
│   - Quản lý xe đang gửi & Lịch sử xe vào/ra                   │
│   - Quản lý vé tháng đã phát hành                             │
│   - Hàng đợi ngoại tuyến (Offline Sync Queue)                 │
│   - Kết nối Firestore / Firebase Backend                      │
└───────────────────────────────────────────────────────────────┘
```

- **Thực thể dữ liệu**:
  - `ParkingLot`: Thông tin bãi, sức chứa, chỗ trống, giá theo QĐ 35, cự ly ga metro, trạng thái cập nhật.
  - `ParkedVehicle`: Xe đang trong bãi (biển số 4 số cuối, loại xe, giờ vào, mã vé QR).
  - `VehicleLog`: Nhật ký lượt xe vào/ra, phương thức thanh toán, doanh thu.
  - `UserMonthlyPass`: Vé tháng người dùng đã kích hoạt.
