# ParkEasy — chuẩn bị build ứng dụng Android APK

Dự án này dùng Capacitor để đóng gói giao diện React/Vite hiện có thành ứng dụng Android. APK chưa được build sẵn trong gói này.

## Cách dễ nhất nếu bạn không quen lập trình: build APK bằng GitHub Actions (miễn phí trong hạn mức)

1. Giải nén ZIP này.
2. Tạo repository trên GitHub và tải toàn bộ nội dung thư mục dự án lên repository (đừng tải nguyên file ZIP vào repository).
3. Mở tab **Actions** của repository và cho phép Actions nếu GitHub hỏi.
4. Chọn workflow **Build ParkEasy Android APK** → **Run workflow**. Nếu workflow không hiện, kiểm tra file `.github/workflows/build-android-apk.yml` đã được tải lên.
5. Khi workflow chạy xong có dấu xanh, mở lần chạy đó, kéo xuống **Artifacts**, tải `ParkEasy-debug-apk`.
6. Giải nén artifact để lấy `app-debug.apk`, gửi file sang điện thoại Android và mở file để cài. Có thể cần cho phép cài ứng dụng từ nguồn này trong phần cài đặt Android.

## Build trên máy tính bằng Android Studio

Yêu cầu: Node.js 22+, Android Studio và Android SDK. Mở terminal tại thư mục dự án rồi chạy:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio mở ra thì chờ Gradle Sync hoàn tất. Chọn **Build → Build Bundle(s) / APK(s) → Build APK(s)**. APK debug thường nằm tại `android/app/build/outputs/apk/debug/app-debug.apk`.

Nếu thư mục `android` đã tồn tại, không chạy `npx cap add android` lần nữa; chỉ chạy `npm run build` rồi `npx cap sync android`.

## Lưu ý

- Đây là APK **debug để thử nghiệm**, chưa phải bản release ký số để phát hành chính thức.
- Đây là bản đóng gói giao diện hiện có; các tính năng cần backend, tài khoản, bản đồ hoặc dữ liệu thời gian thực vẫn cần dịch vụ tương ứng để hoạt động thật.
- Tên package Android hiện đặt là `com.parkeasy.app`.
- Nếu build báo lỗi, lưu log lỗi và gửi lại để xử lý đúng lỗi đó.
